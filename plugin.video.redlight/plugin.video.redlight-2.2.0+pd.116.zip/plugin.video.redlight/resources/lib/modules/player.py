# -*- coding: utf-8 -*-
import os
import xbmc
import xbmcgui
import json
import time
import traceback
from threading import Thread
from apis.trakt_api import make_trakt_slug
from caches.settings_cache import get_setting
from modules import kodi_utils as ku, settings as st, watched_status as ws
from modules.thread_tools import TrackedThreads, log_live_threads
# logger = ku.logger

PROP_RESOLVE_CANCEL = 'redlight.resolve_cancelled'
PROP_PLAY_OPENING = 'redlight.play_opening'
PROP_NEXTEP_PENDING = 'redlight.nextep_pending'
PROP_NEXTEP_PREP_SCHEDULED = 'redlight.nextep_prep_scheduled'
PROP_NEXTEP_PREP_DECLINED = 'redlight.nextep_prep_declined'
PROP_AUTOSCRAPE_NEXTEP_READY = 'redlight.autoscrape_nextep_ready'
PROP_NEXTEP_AUTOPLAY_CANCELLED = 'redlight.nextep_autoplay_cancelled'
PROP_NEXTEP_NATURAL_END = 'redlight.nextep_natural_end'
# How long play_video waits at the end for the threads this player started (scrobbles,
# watched marks, bookmarks, prefetches, subtitle/notification fetches) before it returns
# and the invocation ends; Kodi tears the sub-interpreter down shortly after (#133).
_END_THREAD_JOIN_SEC = 5
PROP_RANDOM_CONTINUAL_SKIP_ATTEMPTS = 'redlight.random_continual_skip_attempts'
PROP_ACTIVE_PLAYBACK_KEY = 'redlight.active_playback_key'
PROP_SKIP_EPISODE = 'redlight.skip_episode_requested'
# Set by the playing monitor when it took the skip over with the prepared next episode (#1).
PROP_SKIP_EPISODE_ACK = 'redlight.skip_episode_ack'
_SKIP_ACK_WAIT_MS = 2000
# #1 C410: how long a claimed skip waits for its on-demand prep before stopping the old way.
_SKIP_PREP_WAIT_SEC = 30
# #1 early prep: the next episode is prepared this far into the current one (and no sooner than the
# intro prompt is done and 10 s after the last seek), instead of about 85 s before the end.
_EARLY_PREP_SEC = 20
# An 'end' this far before the real end is a broken stream (demuxer EOF), not the episode ending (C447).
_PREMATURE_END_SEC = 300
# Stage 2 (cloud rungs when stage 1's folders-only look found nothing) and the deferred warm read.
_EARLY_STAGE2_SEC = 60
_EARLY_PREP_SEEK_QUIET_SEC = 10
# Set while a claimed skip waits for its prep; the prep then skips the warm read so it stashes sooner.
PROP_SKIP_PREP_WAITING = 'redlight.skip_prep_waiting'
_NEXTEP_NATURAL_END_SEC = 15
# #199 C6: the queued next-episode marker comes off the playlist this close to the end, so a natural
# end never advances into it; Red Light's own next-episode hand-off owns the end.
_QUEUED_NEXT_DROP_SEC = _NEXTEP_NATURAL_END_SEC + 5
QUEUED_NEXT_MODE = 'playback.queued_next'
# Set by the marker's own plugin call. Kodi drops the marker as unplayable and ends the playlist, so
# by the end handling its position is gone; this property is what survives (#199 C6, 28.09.26).
PROP_QUEUED_NEXT_HIT = 'redlight.queued_next_hit'
# #1 C417: set by an episode whose Next key moved Kodi onto the real next file queued behind it; the
# stash play it schedules then adopts that already-playing file instead of opening it again.
PROP_ADOPT_QUEUED = 'redlight.adopt_queued'
# #1 C418: for the skin's OSD "next episode ready" button. 'true' while the next episode is prepared
# (a stash, not cancelled); the label is "S02E07 Title". The button runs the skip route.
PROP_NEXTEP_READY = 'redlight.nextep_ready'
PROP_NEXTEP_READY_LABEL = 'redlight.nextep_ready_label'
# A stream Kodi gives up on mid-play (#107: a TorBox range request left hanging past curl's
# low-speed timeout) ends playback exactly the way the file ending does, so "early" is
# measured against the time still to play; the player callbacks tell a user Stop apart.
_STALL_MIN_REMAINING_SEC = 60
# Kodi dispatches OnPlayBackStopped only after it has saved the file's state, which took 3.5 s
# after CloseFile on the Shield (12.09.26), so a 2 s wait read a user Stop as a stall. The wait
# ends as soon as any callback lands; only a silent close waits the full time.
_STALL_CALLBACK_WAIT_MS = 10000
# A seek to (or past) the end that Kodi cannot honour closes the stream as EOF, which reads exactly
# like a stall (Veep S02E09, 12.09.26). A seek this recent that aimed near the end is the user's skip.
_SEEK_END_WINDOW_SEC = 30
# How long check_playback_start waits for Kodi to open the stream before giving up (#115).
# Was an implicit ~20 s (0.26 % per 50 ms tick). 30 s covers curl's 15 s low-speed timeout
# on each of the two requests a slow-but-streaming open needs. Setting: playback_open_timeout.
_PLAYBACK_OPEN_TIMEOUT_SEC = 30
_PLAYBACK_OPEN_TICK_MS = 50
# #1 bug G: a stream that has played this long with a real duration counts as open even when
# fullscreen never came up (the resolve dialog stayed on top of it).
_OPEN_WITHOUT_FULLSCREEN_MS = 3000
# Movies-only: fire stingers alert ~3 min before other alert sources would (typical 90% vs 95% gap on ~1 hr).
_STINGER_EARLY_OFFSET_SEC = 180
_NEXTEP_SUB_FETCH_DEFER_SEC = 45
_NEXTEP_CLOSE_EARLY_PLAY_SEC = 4
_NEXTEP_CLOSE_POLL_MS = 250
_RESUME_CHECKPOINT_INTERVAL_SEC = 60
_INTRO_SKIP_PROMPT_EARLY_SEC = 15
_INTRO_SKIP_PROMPT_COUNTDOWN_SEC = 15
_INTRO_SKIP_EARLY_START_SEC = 120
_INTRO_SKIP_SETTLE_SEC = 4
_INTRO_SKIP_SETTLE_MAX_WAIT_SEC = 12
_INTRO_SKIP_SETTLE_JUMP_SEC = 20
_INTRO_CHAPTER_MIN_START_SEC = 5
_INTRO_CHAPTER_MIN_SEGMENT_SEC = 10
_INTRO_CHAPTER_MIN_END_SEC = 15
_INTRO_SKIP_POST_END_GRACE_SEC = 20

def abnormal_playback_end(curr_time, total_time, user_stopped=False, superseded=False, cancelled=False, media_marked=False, min_remaining=_STALL_MIN_REMAINING_SEC):
	"""True when playback ended where nobody asked it to (#107): not a user Stop, not Redlight
	replacing it (next episode), not a resolve cancel, not already past the watched mark, and
	with far more than the natural-end threshold still to play. Kodi surfaces no error for a
	stream that dies mid-play, so this is the whole signal."""
	if user_stopped or superseded or cancelled or media_marked: return False
	try: curr, total = float(curr_time), float(total_time)
	except (TypeError, ValueError): return False
	if total < 60 or curr <= 0: return False
	return (total - curr) > min_remaining

def silent_open_failure(curr_time, total_time, user_stopped=False, superseded=False, cancelled=False, media_marked=False):
	"""True when playback reached monitor() -- #115's open check already confirmed a real duration
	and fullscreen video -- but no play time was ever recorded before it closed (#190: a curl read
	failure straight after OpenFile, which Kodi closes as a clean end with no dialog of its own).
	abnormal_playback_end requires real curr_time progress and so silently drops exactly this case,
	since curr_time never left zero."""
	if user_stopped or superseded or cancelled or media_marked: return False
	try: curr, total = float(curr_time or 0), float(total_time or 0)
	except (TypeError, ValueError): return False
	if total < 60: return False
	return curr <= 0

def stall_end_signal(stopped, ended, error):
	"""What Kodi said about how playback closed (#107): 'stopped' for a Stop, 'stall' for an
	end-of-file or error well before the end (a dead stream closes as EOF), None while nothing
	has arrived. Only 'stall' may trigger a re-resolve; a close with no signal is left alone,
	because resuming a show the user just stopped is worse than missing one resume."""
	if stopped: return 'stopped'
	if ended or error: return 'stall'
	return None

def seek_to_end(last_seek, total_time, now, window_sec=_SEEK_END_WINDOW_SEC, min_remaining=_STALL_MIN_REMAINING_SEC):
	"""True when the last seek, (when, target seconds), was made within window_sec of now and aimed
	within min_remaining of the end or past it: an early close then is that skip landing on EOF, not a
	stall, so it must not be resumed. A seek into the middle that then stalls still resumes."""
	if not last_seek: return False
	try:
		seek_at, target = float(last_seek[0]), float(last_seek[1])
		total, now = float(total_time), float(now)
	except (TypeError, ValueError, IndexError): return False
	if total <= 0 or now - seek_at > window_sec: return False
	return target >= total - min_remaining

def playback_end_outcome(stopped=False, superseded=False, nextep_handoff=False, abnormal=False, signal=None, seek_end=False):
	"""How playback closed, for the playback log's end row, so stalls can be counted per provider
	(#141). A takeover is 'next_episode' when Redlight's own next-episode play started it and
	'superseded' otherwise; a close near the end or after the watched mark is 'stopped' or 'ended';
	an early close is 'stall' (the #107 resume case), 'seek_end' (a skip that landed on EOF, #157)
	or 'no_callback' (Kodi said nothing, so it was left alone)."""
	if superseded: return 'next_episode' if nextep_handoff else 'superseded'
	if signal == 'stopped': return 'stopped'
	if not abnormal: return 'stopped' if stopped else 'ended'
	if signal is None: return 'no_callback'
	if seek_end: return 'seek_end'
	return 'stall'

def playback_open_timeout_ms(setting_value=None, default_sec=_PLAYBACK_OPEN_TIMEOUT_SEC):
	"""The open window in ms from the playback_open_timeout setting (integer seconds, #115).
	Anything unparseable or below one second falls back to the default."""
	try: seconds = int(float(setting_value))
	except (TypeError, ValueError): seconds = default_sec
	if seconds < 1: seconds = default_sec
	return seconds * 1000

def playback_open_percent(elapsed_ms, timeout_ms):
	"""Resolver progress for the open window, 0..100, one decimal like the old per-tick climb."""
	try:
		if timeout_ms <= 0: return 100.0
		return round(min(100.0, elapsed_ms * 100.0 / timeout_ms), 1)
	except (TypeError, ZeroDivisionError): return 100.0

def open_window_expired_outcome(is_playing, total_time):
	"""What playback_successful becomes when the open window runs out (#115). A stream Kodi is
	already playing with a real duration has opened, just slowly (an MKV index seek under curl's
	threshold, or fullscreen not active yet); stopping it now would kill a working playback, so it
	counts as success. Anything else is the old failure."""
	if not is_playing: return False
	return total_time not in ('0.0', '', 0, 0.0, None)

def request_skip_episode():
	"""#199 C7: mode=playback.skip_episode, 'play next episode now'. Kodi's Next only walks chapters
	because Red Light hands it one item, so a key or a Yatse button can run
	RunPlugin(plugin://plugin.video.redlight/?mode=playback.skip_episode) instead. Only acts on a
	play Red Light owns: flags the skip and stops, and the player's end handling marks the episode
	watched and starts the next one."""
	if not ku.get_property(PROP_ACTIVE_PLAYBACK_KEY):
		ku.notification('Play next episode: nothing from Red Light is playing', 3000)
		return False
	ku.clear_property(PROP_SKIP_EPISODE_ACK)
	ku.set_property(PROP_SKIP_EPISODE, 'true')
	# #1: when the next episode is already prepared, the playing monitor hands it over the way the
	# Next Up dialog's Play does, from fullscreen, so there is no stop, no home screen and no fresh
	# scrape. Give it one or two ticks to claim the skip; otherwise stop and start the next episode.
	waited = 0
	while waited < _SKIP_ACK_WAIT_MS:
		if ku.get_property(PROP_SKIP_EPISODE_ACK) == 'true':
			ku.clear_property(PROP_SKIP_EPISODE_ACK)
			ku.logger('Red Light', 'Play next episode now: handed to the prepared next episode')
			return True
		ku.sleep(100)
		waited += 100
	ku.logger('Red Light', 'Play next episode now: stopping the current episode')
	ku.kodi_player().stop()
	return True

def queued_next_selected(argv):
	"""#199 C6: Kodi reached the queued next-episode marker (the remote's plain Next key). The playing
	episode is already stopping by then; its end handling sees the playlist moved onto the marker
	and does the skip. This invocation only has to let Kodi drop the marker quietly."""
	ku.set_property(PROP_QUEUED_NEXT_HIT, 'true')
	ku.release_resolve_handle(argv)
	ku.logger('Red Light', 'Play next episode now: Next key reached the queued marker')
	return True

class RedLightPlayer(xbmc.Player):
	def __init__ (self):
		xbmc.Player.__init__(self)
		self._cb_started, self._cb_stopped, self._cb_ended = False, False, False
		self.playback_error = False
		self.stall_position = None
		self.end_outcome = None
		self._last_seek = None
		# Every thread this player starts (scrobbles, watched marks, bookmarks, prefetches) is
		# tracked here and joined by _join_end_threads() before play_video returns (#133).
		self._bg = TrackedThreads('playback threads')

	# Kodi delivers these on the addon thread while it sits in xbmc.sleep(). A Stopped queued
	# for the previous playback (Redlight's own stop before this open) arrives before our
	# Started and is ignored, so the flags describe this player's stream only.
	def onPlayBackStarted(self): self._cb_started = True
	def onAVStarted(self): self._cb_started = self._cb_avstarted = True
	def onPlayBackStopped(self):
		if self._cb_started: self._cb_stopped = True
	def onPlayBackEnded(self):
		if self._cb_started: self._cb_ended = True
	def onPlayBackError(self): self.playback_error = True
	def onPlayBackSeek(self, seek_time, seek_offset):
		# Kodi passes the seek target in ms; seek_to_end() reads it when the stream closes early.
		try: self._last_seek = (time.time(), float(seek_time) / 1000.0)
		except (TypeError, ValueError): pass

	def _resolve_cancelled(self):
		if not self.is_generic and (self.sources_object._resolve_user_cancelled or self.sources_object.cancel_all_playback):
			return True
		return ku.get_property(PROP_RESOLVE_CANCEL) == 'true'

	def _spawn(self, target, args=(), kwargs=None, name=None, daemon=False):
		# Tracked so _join_end_threads() can wait for it before play_video returns (#133).
		try: return self._bg.spawn(target, args=args, kwargs=kwargs, name=name, daemon=daemon)
		except Exception:
			thread = Thread(target=target, args=args, kwargs=kwargs or {}, name=name, daemon=daemon)
			thread.start()
			return thread

	def _join_end_threads(self, timeout=_END_THREAD_JOIN_SEC):
		# Bounded wait for the scrobble / watched-mark / bookmark / prefetch threads before
		# play_video returns. Kodi's sub-interpreter teardown starts shortly after the
		# invocation's main code returns, so a thread still alive here is a thread racing that
		# teardown (#133). An overrun is logged by TrackedThreads.join_all itself.
		try: alive = self._bg.join_all(timeout)
		except Exception: alive = []
		try: log_live_threads('playback')
		except Exception: pass
		return alive

	def run(self, url=None, obj=None):
		# #1 C426: every hand-off to the player ends a quiet start; the sources window never shows now.
		try:
			dialog = getattr(obj, 'progress_dialog', None)
			if dialog is not None and hasattr(type(dialog), 'suppress') and not dialog.materialized: dialog.suppress()
		except Exception: pass
		ku.hide_busy_dialog()
		self.clear_playback_properties(clear_navigation=False)
		if not url:
			self.is_generic = obj == 'video'
			return self.run_error('No playable link was returned.')
		try: return self.play_video(url, obj)
		except:
			self.is_generic = obj == 'video'
			return self.run_error()

	def play_video(self, url, obj):
		self.set_constants(url, obj)
		if self.is_generic:
			ku.clear_video_playlist()
		if not self.is_generic and self._resolve_cancelled():
			self.playback_successful = False
			self.cancel_all_playback = True
			self.sources_object.cancel_all_playback = True
			self.sources_object._resolve_user_cancelled = True
			return
		ku.volume_checker()
		ku.set_property(PROP_PLAY_OPENING, 'true')
		self._queued_next = False
		self._queued_real = None
		self._advanced_to_queued = False
		ku.clear_property(PROP_QUEUED_NEXT_HIT)
		listitem = self.make_listing()
		adopted = self._adopt_queued_play()
		if not adopted and not self._play_with_queued_next(listitem): self.play(self.url, listitem)
		if self.is_generic:
			self.check_playback_start_generic()
			if self.playback_successful:
				ku.clear_property(PROP_PLAY_OPENING)
			else:
				self.safe_stop()
				return self.run_error()
		else:
			self.check_playback_start()
			if self.playback_successful:
				ku.clear_property(PROP_PLAY_OPENING)
				try:
					if self.sources_object:
						self.sources_object._release_resolve_busy()
						self.sources_object._release_sources_busy()
				except:
					pass
				self._register_active_playback()
				# #1 bug H (28.09.26): the open is confirmed, so tell play_file now. It used to learn
				# this only from the monitor loop's first tick (playback_close_dialogs), so a Stop
				# during monitor()'s setup left it None and play_file opened the next source.
				try: self.sources_object.playback_successful = True
				except Exception: pass
				if adopted: self._adopt_resume_seek()
				# Confirmed playback only, so failed resolves don't create entries. No-op unless
				# the user turned the playback log on.
				try:
					from modules.playback_log import log_playback
					log_playback(self)
				except Exception: pass
				self.monitor()
			else:
				self.sources_object.playback_successful = self.playback_successful
				cancelled = self.cancel_all_playback or self.sources_object._resolve_user_cancelled
				if cancelled:
					self.sources_object.cancel_all_playback = True
					self.sources_object._resolve_user_cancelled = True
				else:
					self.sources_object.cancel_all_playback = self.cancel_all_playback
				if cancelled:
					if not self.sources_object._resolve_user_cancelled:
						self.kill_dialog()
				else:
					# Keep the resolver progress UI so play_file can try the next queued source.
					self.run_error()
					self._dismiss_kodi_playback_error_dialog()
				self.safe_stop()
		# Both the normal-end and user-stop paths reach here through monitor()/safe_stop() above;
		# Kodi tears this invocation's sub-interpreter down shortly after play_video returns, so
		# any scrobble/watched-mark/bookmark/prefetch thread still running is racing that teardown
		# (#133). Bounded join, then log whatever is still alive.
		self._join_end_threads()
		try: del self.kodi_monitor
		except: pass

	def _dismiss_kodi_playback_error_dialog(self):
		# Kodi shows DialogConfirm (okdialog) when demux/open fails. Force-close so
		# mid-queue resolve retries do not flash a brief confirm over the resolver UI.
		if ku.get_visibility('Window.IsVisible(okdialog)'):
			ku.close_dialog('okdialog')
			return True
		return False

	def _confirm_open(self, elapsed_ms):
		"""The open succeeded once the video plays with a real duration in fullscreen. #1 bug G
		(Shield 28.09.26 09:26): after a curl reconnect right at the start, fullscreen never came
		up, the resolve dialog stayed over the playing video, and this loop waited on until the
		service took the play as foreign (#143). Now, playing with a duration for
		_OPEN_WITHOUT_FULLSCREEN_MS without fullscreen: bring fullscreen up and count it as open."""
		try: total = self.getTotalTime()
		except Exception: return
		if total in ('0.0', '', 0.0, 0, None):
			self._open_playing_since = None
			return
		if ku.get_visibility('Window.IsActive(fullscreenvideo)'):
			self.playback_successful = True
			return
		since = getattr(self, '_open_playing_since', None)
		if not isinstance(since, (int, float)):
			self._open_playing_since = elapsed_ms
			return
		if elapsed_ms - since < _OPEN_WITHOUT_FULLSCREEN_MS: return
		ku.logger('Red Light', 'Playback open: playing %.1fs without fullscreen; bringing it up and continuing (#1 bug G)' % ((elapsed_ms - since) / 1000.0))
		try: ku.execute_builtin('ActivateWindow(fullscreenvideo)')
		except Exception: pass
		self.playback_successful = True

	def _playback_open_timeout_ms(self):
		try: return playback_open_timeout_ms(st.playback_open_timeout())
		except Exception: return playback_open_timeout_ms(None)

	def _open_window_expired(self):
		try: total = self.getTotalTime()
		except Exception: total = None
		try: playing = bool(self.isPlayingVideo())
		except Exception: playing = False
		self.playback_successful = open_window_expired_outcome(playing, total)
		if self.playback_successful:
			ku.logger('Red Light', 'Playback open window expired with the video already playing; leaving it alone (#115)')

	def check_playback_start_generic(self):
		elapsed_ms, timeout_ms = 0, self._playback_open_timeout_ms()
		while self.playback_successful is None:
			ku.hide_busy_dialog()
			if self.kodi_monitor.abortRequested():
				self.playback_successful = False
				break
			elif elapsed_ms >= timeout_ms:
				self._open_window_expired()
				break
			elif self._dismiss_kodi_playback_error_dialog():
				self.playback_successful = False
			elif self.isPlayingVideo():
				try:
					if ku.get_property('redlight.browse_playback') == 'true':
						browse_window = getattr(self, '_browse_results_window', None)
						if browse_window:
							try:
								browse_window.selected = (None, '')
								browse_window.close()
								self._browse_results_window = None
							except:
								pass
					if not ku.get_visibility('Window.IsActive(fullscreenvideo)'):
						ku.execute_builtin('ActivateWindow(fullscreenvideo)', block=False)
					if self.getTotalTime() not in ('0.0', '', 0.0, None):
						self.playback_successful = True
				except:
					pass
			elapsed_ms += _PLAYBACK_OPEN_TICK_MS
			ku.sleep(_PLAYBACK_OPEN_TICK_MS)

	def check_playback_start(self):
		elapsed_ms, timeout_ms = 0, self._playback_open_timeout_ms()
		self._open_playing_since = None
		while self.playback_successful is None:
			ku.hide_busy_dialog()
			if getattr(self, '_queued_next', False) and ku.get_property(PROP_QUEUED_NEXT_HIT) == 'true':
				# #1 (W-280926-13): the file never opened and Kodi moved on to the queued marker behind
				# it. That is a failed open, not the Next key: try the next source now instead of
				# waiting out the open timeout (37 s on the Shield).
				ku.clear_property(PROP_QUEUED_NEXT_HIT)
				self._queued_next = False
				ku.logger('Red Light', 'Playback open: Kodi skipped past the file to the queued marker; trying the next source')
				self.playback_successful = False
				break
			if getattr(self, '_cb_stopped', False) and getattr(self, '_cb_avstarted', False) is True:
				# #1 bug F (28.09.26): Kodi only reports Stopped after this stream started, so it is a
				# user Stop while the open was still settling, not a failed source. Treat it as a
				# cancel; before this the loop fell through and the next source was played.
				ku.logger('Red Light', 'Playback stopped by the user while opening: not trying the next source')
				self.sources_object.cancel_all_playback = True
				self.sources_object._resolve_user_cancelled = True
				self.playback_successful = False
				break
			if self._resolve_cancelled():
				self.sources_object.cancel_all_playback = True
				self.sources_object._resolve_user_cancelled = True
				self.playback_successful = False
				self.safe_stop()
				break
			elif not self.sources_object.progress_dialog:
				if self._resolve_cancelled():
					self.sources_object.cancel_all_playback = True
					self.sources_object._resolve_user_cancelled = True
					self.playback_successful = False
					self.safe_stop()
					break
				elif self.isPlayingVideo():
					self._confirm_open(elapsed_ms)
			elif self.sources_object.progress_dialog.skip_resolved(): self.playback_successful = False
			elif self.sources_object.progress_dialog.iscanceled() or self.kodi_monitor.abortRequested():
				self.sources_object.cancel_all_playback = True
				self.sources_object._resolve_user_cancelled = True
				self.playback_successful = False
				self.safe_stop()
				break
			elif elapsed_ms >= timeout_ms:
				self._open_window_expired()
				break
			elif self._dismiss_kodi_playback_error_dialog():
				self.playback_successful = False
			elif self.isPlayingVideo():
				if self._resolve_cancelled():
					self.sources_object.cancel_all_playback = True
					self.sources_object._resolve_user_cancelled = True
					self.playback_successful = False
					self.safe_stop()
					break
				self._confirm_open(elapsed_ms)
			elapsed_ms += _PLAYBACK_OPEN_TICK_MS
			try:
				if self.sources_object.progress_dialog:
					self.sources_object.progress_dialog.update_resolver(percent=playback_open_percent(elapsed_ms, timeout_ms))
			except: pass
			ku.sleep(_PLAYBACK_OPEN_TICK_MS)

	def playback_close_dialogs(self):
		self.sources_object.playback_successful = True
		self.kill_dialog()
		ku.sleep(200)
		try:
			self.sources_object._force_close_sources_overlay_windows()
		except:
			ku.close_all_dialog()

	def monitor(self):
		playback_superseded = False
		try:
			ensure_dialog_dead, total_check_time = False, 0
			if self.media_type == 'episode':
				play_random_continual = self.sources_object.random_continual
				play_random = self.sources_object.random
				disable_autoplay_next_episode = self.sources_object.disable_autoplay_next_episode
				self.num_episodes = getattr(self.sources_object, 'num_episodes', None)
				if disable_autoplay_next_episode: ku.notification('Scrape with Custom Values - Autoplay Next Episode Cancelled', 4500)
				# #1: an explicit skip may prepare the next episode even with autoplay off, but never
				# for random or custom plays, which have no "next" of their own.
				self._skip_prep_allowed = not any((play_random_continual, play_random, disable_autoplay_next_episode))
				if any((play_random_continual, play_random, disable_autoplay_next_episode)): self.autoplay_nextep, self.autoscrape_nextep = False, False
				else: self.autoplay_nextep, self.autoscrape_nextep = self.sources_object.autoplay_nextep, self.sources_object.autoscrape_nextep
				# Play # Episodes: remaining count includes the current episode.
				try: _play_n = int(self.num_episodes) if self.num_episodes not in (None, '') else 0
				except: _play_n = 0
				if _play_n > 1:
					self.autoplay_nextep, self.autoscrape_nextep = True, False
				elif self.num_episodes not in (None, '') and _play_n <= 1:
					self.autoplay_nextep, self.autoscrape_nextep = False, False
				if self.autoplay_nextep or self.autoscrape_nextep:
					self._log_nextep('Next episode monitor active: autoplay=%s autoscrape=%s play_n=%s' % (
						self.autoplay_nextep, self.autoscrape_nextep, self.num_episodes or ''))
				elif st.autoscrape_next_episode() or st.autoplay_next_episode():
					self._log_nextep('Next episode disabled this play (random=%s random_continual=%s custom_values=%s play_n=%s)' % (
						play_random, play_random_continual, disable_autoplay_next_episode, self.num_episodes or ''))
				if not (play_random or play_random_continual): self._note_rewatch()
			else:
				self.num_episodes = None
				show_stinger, stinger_alert_timing, stingers_percentage_fallback = st.stingers_show(), st.stingers_alert_timing(), st.stingers_percentage()
				play_random_continual, self.autoplay_nextep, self.autoscrape_nextep = False, False, False
			while total_check_time <= 30 and not ku.get_visibility('Window.IsActive(fullscreenvideo)'):
				ku.sleep(100)
				total_check_time += 0.10
			ku.hide_busy_dialog()
			ku.sleep(1000)
			self._trakt_scrobble_start()
			self._simkl_scrobble_start()
			self._punchplay_scrobble_start()
			self._wetrakr_scrobble_start()
			self._maybe_start_subtitle_alert_fetch()
			self._maybe_start_introdb_alert_fetch()
			self._intro_skip_fetch_started = False
			if st.auto_enable_subs() and st.subtitles_source() == '0':
				try:
					from indexers.subtitles import enable_local_subtitles, subtitle_notify_poster
					poster = subtitle_notify_poster(self.meta, self.media_type) if getattr(self, 'meta', None) else ku.get_icon('box_office')
					enable_local_subtitles(self, poster=poster, is_episode=self.media_type == 'episode')
				except:
					self.showSubtitles(True)
			while self.isPlayingVideo():
				# #1 C417: first, so Kodi's switch to the queued file is never read as a takeover.
				if self._queued_real_advanced(): break
				if not self._owns_active_playback():
					playback_superseded = True
					break
				try:
					if not ensure_dialog_dead:
						ensure_dialog_dead = True
						self.playback_close_dialogs()
					_monitor_sleep_ms = 1000
					if self.media_type == 'episode' and getattr(self, '_nextep_close_wait', False) and not getattr(self, '_nextep_stash_play_scheduled', False):
						try:
							_rem = round(float(self.getTotalTime()) - float(self.getTime()))
							if 0 < _rem <= 10:
								_monitor_sleep_ms = _NEXTEP_CLOSE_POLL_MS
						except:
							pass
					ku.sleep(_monitor_sleep_ms)
					self._try_skip_to_stash()
					self._maybe_drop_queued_next()
					self._maybe_queue_real_next()
					self._maybe_requeue_before_end()
					self._update_nextep_ready_flag()
					self._maybe_osd_nextup()
					try: self.total_time, self.curr_time = self.getTotalTime(), self.getTime()
					except: ku.sleep(250); continue
					if not self._valid_playback_duration(self.total_time, self.curr_time):
						ku.sleep(250)
						continue
					if not getattr(self, '_intro_skip_fetch_started', False):
						self._intro_skip_fetch_started = True
						self._start_intro_skip_fetch()
					self._maybe_apply_intro_skip()
					self.current_point = round(float(self.curr_time/self.total_time * 100), 1)
					self._wetrakr_progress_tick()
					self._punchplay_scrobble_progress()
					self._maybe_write_resume_checkpoint()
					if play_random_continual:
						if self._should_prep_random_continual():
							self.random_continual_triggered = True
							self.run_random_continual()
							break
					elif self.current_point >= 90:
						if not self.media_marked: self.media_watched_marker()
					if self.media_type == 'episode':
						if self.autoplay_nextep or self.autoscrape_nextep:
							if not self.nextep_info_gathered:
								if not self._defer_nextep_info(): self.info_next_ep()
							else:
								self._maybe_refresh_nextep_subtitle_timing()
								self._maybe_refresh_nextep_chapter_timing()
								self._maybe_refresh_nextep_introdb_timing()
							try:
								_nextep_remaining = round(float(self.total_time) - float(self.curr_time))
								if _nextep_remaining > 0: ku.set_property('redlight.nextep_remaining', str(_nextep_remaining))
							except: pass
							if self._should_prep_next_ep(): self._schedule_next_ep()
							else: self._maybe_early_stage2()
							self._maybe_early_warm()
							self._try_autoplay_nextep_alert()
							self._try_autoplay_early_stash_play()
							self._try_autoscrape_nextep_ready_notify()
							self._maybe_log_nextep_alert_pending()
					elif show_stinger and not self.movie_stingers_run: 
						final_chapter = self._stinger_trigger_point(stinger_alert_timing, stingers_percentage_fallback)
						if self.current_point >= final_chapter: self.run_movie_stingers()
				except Exception:
					self._log_monitor_tick_error()
				if not self.subs_searched: self.run_subtitles()
			if not ensure_dialog_dead:
				# Stopped before the loop's first tick (bug H): the resolve dialog is still up.
				try: self.playback_close_dialogs()
				except Exception: pass
			natural_end = False
			try:
				_remaining = None
				if getattr(self, 'total_time', None) not in (None, '', 0, 0.0) and getattr(self, 'curr_time', None) not in (None, ''):
					_remaining = round(float(self.total_time) - float(self.curr_time))
				natural_end = (not playback_superseded and _remaining is not None and _remaining <= _NEXTEP_NATURAL_END_SEC)
				if self.autoscrape_nextep and not playback_superseded:
					if natural_end:
						ku.set_property(PROP_NEXTEP_NATURAL_END, 'true')
					else:
						ku.set_property(PROP_NEXTEP_NATURAL_END, 'false')
						try:
							from modules.sources import mark_nextep_autoplay_cancelled
							mark_nextep_autoplay_cancelled()
							self._log_nextep('Autoscrape next episode: cancelled (playback stopped early)')
						except:
							pass
				elif natural_end:
					ku.set_property(PROP_NEXTEP_NATURAL_END, 'true')
			except:
				pass
			autoplay_stash_scheduled = False
			# #1 C417: Kodi may drop out of "playing" for a moment while it switches to the queued
			# file; give the playlist position up to 2 s to settle before reading this as an end.
			if getattr(self, '_queued_real', None) and not self._queued_real_advanced():
				for _ in range(20):
					ku.sleep(100)
					if self._queued_real_advanced(): break
			if self._queued_real_advanced():
				playback_superseded = False
				autoplay_stash_scheduled = self._hand_over_to_queued_real()
			elif not playback_superseded and self.autoplay_nextep:
				try:
					from modules.sources import clear_nextep_autoplay_stash, clear_orphan_nextep_play_stash, nextep_autoplay_cancelled, nextep_end_play_superseded, peek_nextep_autoplay_stash, schedule_nextep_stashed_play, take_nextep_autoplay_stash
					if nextep_autoplay_cancelled() or nextep_end_play_superseded():
						clear_nextep_autoplay_stash()
						clear_orphan_nextep_play_stash()
						if nextep_autoplay_cancelled():
							self._log_nextep('Autoplay next episode: skipped at episode end (cancelled)')
						else:
							self._log_nextep('Autoplay next episode: skipped at episode end (superseded by user playback)')
					elif getattr(self, '_nextep_stash_play_scheduled', False):
						autoplay_stash_scheduled = True
					elif getattr(self, '_nextep_alert_shown', False):
						if peek_nextep_autoplay_stash():
							stash = take_nextep_autoplay_stash()
							if stash:
								self._log_nextep('Autoplay next episode: playing stashed resolve at episode end')
								autoplay_stash_scheduled = schedule_nextep_stashed_play(stash)
					else:
						clear_nextep_autoplay_stash()
				except: pass
			if not autoplay_stash_scheduled:
				ku.hide_busy_dialog()
			# #199 C6: the Next key moved Kodi's playlist onto the queued marker, a skip like C7's.
			if not playback_superseded and not natural_end and not getattr(self, '_advanced_to_queued', False) and self._queued_next_taken():
				ku.set_property(PROP_SKIP_EPISODE, 'true')
				self._log_nextep('Play next episode now: Next key, moving on')
			# #199 C7: request_skip_episode stopped this play to move on; count it as watched.
			skip_requested = not playback_superseded and ku.get_property(PROP_SKIP_EPISODE) == 'true'
			if skip_requested:
				ku.clear_property(PROP_SKIP_EPISODE)
				if not self.media_marked: self.media_watched_marker(force_watched=True)
			# #1 C417: the Next key moved on to the queued file; this episode counts as watched.
			if getattr(self, '_advanced_to_queued', False) and not self.media_marked: self.media_watched_marker(force_watched=True)
			marked_before_end = self.media_marked
			if not playback_superseded and not self.media_marked: self.media_watched_marker()
			self.clear_playback_properties(clear_navigation=False)
			ku.clear_property(PROP_NEXTEP_READY)
			ku.clear_property(PROP_NEXTEP_READY_LABEL)
			self._release_active_playback()
			self._note_abnormal_end(playback_superseded, marked_before_end)
			if skip_requested and not autoplay_stash_scheduled: self._play_next_after_seek_end(explicit=True)
			self._log_playback_end()
		except:
			self._log_monitor_error()
			ku.hide_busy_dialog()
			if self.playback_successful:
				# Playback already opened (#110): a fault in monitor()'s own setup or teardown is
				# not a user cancel. Leave the player alone, let the video run to its end, then
				# write the bookmark the normal path would have written.
				return self._finish_after_monitor_error(playback_superseded)
			self.sources_object.playback_successful = False
			self.sources_object.cancel_all_playback = True
			return self.kill_dialog()

	def _log_monitor_error(self):
		try: ku.logger('Red Light', 'monitor() failed: %s' % traceback.format_exc())
		except Exception: pass

	def _finish_after_monitor_error(self, playback_superseded=False):
		try: self.playback_close_dialogs()
		except Exception: pass
		try:
			while self.isPlayingVideo():
				if not self._owns_active_playback():
					playback_superseded = True
					break
				try: self.total_time, self.curr_time = self.getTotalTime(), self.getTime()
				except Exception: pass
				try:
					if self._valid_playback_duration(self.total_time, self.curr_time):
						self.current_point = round(float(self.curr_time / self.total_time * 100), 1)
				except Exception: pass
				ku.sleep(1000)
		except Exception: pass
		try:
			if not playback_superseded and not self.media_marked: self.media_watched_marker()
		except Exception: pass
		try: self.clear_playback_properties(clear_navigation=False)
		except Exception: pass
		try: self._release_active_playback()
		except Exception: pass
		self.end_outcome = 'monitor_error'
		self._log_playback_end()

	def _log_playback_end(self):
		# No-op unless the playback log is on; never raises (see playback_log.log_playback_end).
		try:
			from modules.playback_log import log_playback_end
			log_playback_end(self)
		except Exception: pass

	def _note_abnormal_end(self, playback_superseded, marked_before_end):
		"""Record where playback died if it ended neither by itself nor by hand (#107).
		play_file reads stall_position to re-resolve and resume a cloud item. Runs after the
		stop-time bookmark is written, so the bookmark already holds the stall position.
		Also sets end_outcome for the playback log's end row, on every path. The quiet paths read
		the Stop flag without waiting for it, so a late Stop near the end can log as 'ended'."""
		self.stall_position = None
		self.end_outcome = None
		try:
			nextep_handoff = bool(getattr(self, '_nextep_alert_shown', False) or getattr(self, '_nextep_stash_play_scheduled', False))
			self.end_outcome = playback_end_outcome(stopped=self._cb_stopped, superseded=playback_superseded, nextep_handoff=nextep_handoff)
			# The early prep sets _nextep_prep_attempted about 20 s in; a premature end (C447) must still reopen.
			if self.is_generic or (getattr(self, '_nextep_prep_attempted', False) and not getattr(self, '_premature_end', False)): return
			cancelled = self.cancel_all_playback or self._resolve_cancelled()
			curr, total = getattr(self, 'curr_time', None), getattr(self, 'total_time', None)
			abnormal = abnormal_playback_end(curr, total, user_stopped=self._cb_stopped, superseded=playback_superseded, cancelled=cancelled, media_marked=marked_before_end)
			# #190: a stream that opened (this function only runs after monitor() started, so Kodi
			# already confirmed a real duration) but never advanced past 0s before closing is dropped
			# by abnormal_playback_end's curr<=0 guard above, and Kodi shows nothing of its own for it.
			silent_fail = (not abnormal) and silent_open_failure(curr, total, user_stopped=self._cb_stopped, superseded=playback_superseded, cancelled=cancelled, media_marked=marked_before_end)
			if not abnormal and not silent_fail: return
			# The callbacks lag isPlayingVideo() by a beat; give a Stop the chance to arrive.
			waited = 0
			while waited < _STALL_CALLBACK_WAIT_MS and not (self._cb_stopped or self._cb_ended or self.playback_error):
				ku.sleep(100)
				waited += 100
			if self.isPlayingVideo():
				self.end_outcome = 'superseded'
				return
			signal = stall_end_signal(self._cb_stopped, self._cb_ended, self.playback_error)
			if silent_fail:
				if signal == 'stall':
					self.end_outcome = 'silent_open_failure'
					ku.logger('Red Light', 'Playback opened but never advanced past 0s on %s before closing (ended=%s error=%s); notifying (#190)' % (
						self.playing_filename or '', self._cb_ended, self.playback_error))
					try: ku.notification('Playback failed to start: the stream closed with an error. Try again or pick another source.', 5000)
					except Exception: pass
				return
			last_seek = getattr(self, '_last_seek', None)
			seek_end = signal == 'stall' and seek_to_end(last_seek, total, time.time())
			self.end_outcome = playback_end_outcome(stopped=self._cb_stopped, abnormal=True, signal=signal, seek_end=seek_end)
			if signal != 'stall':
				if signal is None:
					ku.logger('Red Light', 'Playback closed at %ds of %ds on %s with no stop, end or error callback within %ds; not resuming' % (
						float(curr), float(total), self.playing_filename or '', _STALL_CALLBACK_WAIT_MS // 1000))
				return
			if seek_end:
				ku.logger('Red Light', 'Playback closed at %ds of %ds on %s right after a seek to %ds; a skip to the end, not resuming' % (
					float(curr), float(total), self.playing_filename or '', last_seek[1]))
				self._play_next_after_seek_end()
				return
			self.stall_position = (float(curr), float(total))
			ku.logger('Red Light', 'Playback ended early at %ds of %ds on %s (ended=%s error=%s stopped=%s)' % (
				float(curr), float(total), self.playing_filename or '', self._cb_ended, self.playback_error, self._cb_stopped))
		except: pass

	def make_listing(self):
		listitem = ku.make_listitem()
		listitem.setPath(self.url)
		listitem.setContentLookup(False)
		if self.is_generic:
			info_tag = listitem.getVideoInfoTag(True)
			info_tag.setMediaType('video')
			play_name = ku.get_property('redlight.tb.play_filename') or self.url
			info_tag.setFilenameAndPath(play_name)
			info_tag.setTitle(os.path.basename(play_name) if play_name else '')
			mime = ku.get_property('redlight.tb.play_mime')
			if not mime:
				path_lower = (play_name or self.url or '').lower().split('|')[0].split('?')[0]
				for ext, mt in (
					('.m2ts', 'video/mp2t'), ('.mts', 'video/mp2t'), ('.ts', 'video/mp2t'),
					('.mkv', 'video/x-matroska'), ('.mp4', 'video/mp4'), ('.avi', 'video/x-msvideo'),
					('.mov', 'video/quicktime'), ('.webm', 'video/webm'),
				):
					if path_lower.endswith(ext):
						mime = mt
						break
			if mime:
				try:
					listitem.setMimeType(mime)
				except Exception:
					pass
			self._disable_kodi_url_resume(listitem)
		else:
			# #124: sources.py publishes a mime hint from the file extension for cloud/debrid items so
			# Kodi can skip its HEAD request (content lookup is already off above).
			play_mime = ku.get_property('redlight.play_mime')
			if play_mime:
				try: listitem.setMimeType(play_mime)
				except Exception: pass
			self.tmdb_id, self.imdb_id, self.tvdb_id = self.meta_get('tmdb_id', ''), self.meta_get('imdb_id', ''), self.meta_get('tvdb_id', '')
			self.media_type, self.title, self.year = self.meta_get('media_type'), self.meta_get('title'), self.meta_get('year')
			self.season, self.episode = self.meta_get('season', ''), self.meta_get('episode', '')
			poster = self.meta_get('poster') or ku.get_icon('box_office')
			fanart = self.meta_get('fanart') or ku.get_addon_fanart()
			clearlogo = self.meta_get('clearlogo') or ''
			duration, genre, trailer, mpaa = self.meta_get('duration'), self.meta_get('genre', ''), self.meta_get('trailer'), self.meta_get('mpaa')
			rating, votes = self.meta_get('rating'), self.meta_get('votes')
			premiered, studio, tagline = self.meta_get('premiered'), self.meta_get('studio', ''), self.meta_get('tagline')
			director, writer, country = self.meta_get('director', ''), self.meta_get('writer', ''), self.meta_get('country', '')
			cast = self.meta_get('short_cast', []) or self.meta_get('cast', []) or []
			listitem.setLabel(self.title)
			fresh_start = False
			if self.media_type == 'movie':
				plot = self.meta_get('plot')
				listitem.setArt({'poster': poster, 'fanart': fanart, 'icon': poster, 'clearlogo': clearlogo})
				info_tag = listitem.getVideoInfoTag(True)
				info_tag.setMediaType('movie'), info_tag.setTitle(self.title), info_tag.setOriginalTitle(self.meta_get('original_title')), info_tag.setPlot(plot)
				info_tag.setYear(int(self.year)), info_tag.setRating(rating), info_tag.setVotes(votes), info_tag.setMpaa(mpaa)
				info_tag.setDuration(duration), info_tag.setCountries(country), info_tag.setTrailer(trailer), info_tag.setPremiered(premiered)
				info_tag.setTagLine(tagline), info_tag.setStudios(studio), info_tag.setIMDBNumber(self.imdb_id), info_tag.setGenres(genre)
				info_tag.setWriters(writer), info_tag.setDirectors(director), info_tag.setUniqueIDs({'imdb': self.imdb_id, 'tmdb': str(self.tmdb_id)})
				info_tag.setCast([ku.kodi_actor()(name=item['name'], role=item['role'], thumbnail=item['thumbnail']) for item in cast])
			else:
				if st.avoid_episode_spoilers() and int(self.meta_get('playcount', '0')) == 0: plot = self.meta_get('tvshow_plot') or '* Hidden to Prevent Spoilers *'
				else: plot = self.meta_get('plot') or self.meta_get('tvshow_plot')
				listitem.setArt({'poster': poster, 'fanart': fanart, 'icon': poster, 'clearlogo': clearlogo, 'tvshow.poster': poster, 'tvshow.clearlogo': clearlogo})
				info_tag = listitem.getVideoInfoTag(True)
				info_tag.setMediaType('episode'), info_tag.setTitle(self.meta_get('ep_name')), info_tag.setOriginalTitle(self.meta_get('original_title'))
				info_tag.setTvShowTitle(self.title), info_tag.setTvShowStatus(self.meta_get('status')), info_tag.setSeason(self.season), info_tag.setEpisode(self.episode)
				info_tag.setPlot(plot), info_tag.setYear(int(self.year)), info_tag.setRating(rating), info_tag.setVotes(votes)
				info_tag.setMpaa(mpaa), info_tag.setDuration(duration), info_tag.setTrailer(trailer), info_tag.setFirstAired(premiered)
				info_tag.setStudios(studio), info_tag.setIMDBNumber(self.imdb_id), info_tag.setGenres(genre), info_tag.setWriters(writer)
				info_tag.setDirectors(director), info_tag.setUniqueIDs({'imdb': self.imdb_id, 'tmdb': str(self.tmdb_id), 'tvdb': str(self.tvdb_id)})
				info_tag.setCast([ku.kodi_actor()(name=item['name'], role=item['role'], thumbnail=item['thumbnail']) for item in cast])
				fresh_start = self._nextep_aio_en_fresh_start()
				if fresh_start:
					self.playback_percent = 0.0
					try:
						info_tag.setFilenameAndPath('%s S%02dE%02d %s' % (
							self.title or '', int(self.season), int(self.episode), (self.playing_filename or '')[:120]))
					except:
						info_tag.setFilenameAndPath(self.url)
				else:
					info_tag.setFilenameAndPath(self.url)
			self.set_resume_point(listitem)
			if self.url and str(self.url).startswith('http'):
				self._disable_kodi_url_resume(listitem, keep_start_percent=not fresh_start)
			self.set_playback_properties()
		return listitem

	def _trakt_scrobble_start(self):
		if self.is_generic or st.watched_indicators() != 1 or not st.trakt_user_active(): return
		from apis.trakt_api import trakt_scrobble, trakt_official_status
		if not trakt_official_status(self.media_type): return
		percent = self.playback_percent if self.playback_percent else 0
		self._spawn(trakt_scrobble, args=('start', self.media_type, self.tmdb_id, percent, self.season, self.episode), name='trakt_scrobble_start')

	def _trakt_scrobble_stop(self, percent):
		# Synchronous: ending playback tears down the player; a background thread often never finishes, leaving Trakt Playing now stuck.
		if self.is_generic or st.watched_indicators() != 1 or not st.trakt_user_active(): return
		from apis.trakt_api import trakt_scrobble, trakt_official_status
		if not trakt_official_status(self.media_type): return
		try: pct = float(percent or 0)
		except: pct = 0
		# Trakt returns 422 for stop below 1% and leaves watching active — clamp so Playing now still clears.
		if pct < 1: pct = 1
		trakt_scrobble('stop', self.media_type, self.tmdb_id, pct, self.season, self.episode)

	def _simkl_scrobble_start(self):
		if self.is_generic or st.watched_indicators() != 2 or not st.simkl_user_active(): return
		from apis.simkl_api import simkl_scrobble, simkl_official_status
		if not simkl_official_status(self.media_type): return
		percent = self.playback_percent if self.playback_percent else 0
		self._spawn(simkl_scrobble, args=('start', self.media_type, self.tmdb_id, percent, self.season, self.episode), name='simkl_scrobble_start')

	def _simkl_scrobble_stop(self, percent):
		if self.is_generic or st.watched_indicators() != 2 or not st.simkl_user_active(): return
		from apis.simkl_api import simkl_scrobble, simkl_official_status
		if not simkl_official_status(self.media_type): return
		self._spawn(simkl_scrobble, args=('stop', self.media_type, self.tmdb_id, percent, self.season, self.episode), name='simkl_scrobble_stop')

	def _punchplay_scrobble_start(self):
		if self.is_generic or st.watched_indicators() != 4 or not st.punchplay_user_active(): return
		from apis.punchplay_api import punchplay_scrobble, punchplay_official_status
		if not punchplay_official_status(self.media_type): return
		import uuid
		self._punchplay_session_id = str(uuid.uuid4())
		self._punchplay_last_progress_send = 0
		percent = self.playback_percent if self.playback_percent else 0
		self._spawn(punchplay_scrobble, args=('start', self.media_type, self.tmdb_id, percent, self.season, self.episode),
			kwargs={'title': getattr(self, 'title', '') or '', 'year': getattr(self, 'year', None),
				'session_id': self._punchplay_session_id}).start()

	def _punchplay_scrobble_progress(self):
		if self.is_generic or st.watched_indicators() != 4 or not st.punchplay_user_active(): return
		from apis.punchplay_api import punchplay_scrobble, punchplay_official_status
		if not punchplay_official_status(self.media_type): return
		now = time.time()
		last = getattr(self, '_punchplay_last_progress_send', 0) or 0
		if now - last < 30: return
		self._punchplay_last_progress_send = now
		session_id = getattr(self, '_punchplay_session_id', None)
		self._spawn(punchplay_scrobble, args=('progress', self.media_type, self.tmdb_id, self.current_point, self.season, self.episode),
			kwargs={'title': getattr(self, 'title', '') or '', 'year': getattr(self, 'year', None),
				'session_id': session_id}).start()

	def _punchplay_scrobble_stop(self, percent):
		if self.is_generic or st.watched_indicators() != 4 or not st.punchplay_user_active(): return
		from apis.punchplay_api import punchplay_scrobble, punchplay_official_status
		if not punchplay_official_status(self.media_type): return
		session_id = getattr(self, '_punchplay_session_id', None)
		self._spawn(punchplay_scrobble, args=('stop', self.media_type, self.tmdb_id, percent, self.season, self.episode),
			kwargs={'title': getattr(self, 'title', '') or '', 'year': getattr(self, 'year', None),
				'session_id': session_id}).start()

	def _wetrakr_meta_kwargs(self, percent):
		ep_title = ''
		show_title = None
		if self.media_type == 'episode':
			try: ep_title = (self.meta_get('ep_name') if getattr(self, 'meta_get', None) else '') or ''
			except: ep_title = ''
			show_title = getattr(self, 'title', '') or ''
			title = ep_title or show_title
		else:
			title = getattr(self, 'title', '') or ''
		return {
			'progress': percent,
			'title': title,
			'year': getattr(self, 'year', None),
			'tmdb_id': getattr(self, 'tmdb_id', None),
			'imdb_id': getattr(self, 'imdb_id', None),
			'tvdb_id': getattr(self, 'tvdb_id', None),
			'season': getattr(self, 'season', None),
			'episode': getattr(self, 'episode', None),
			'show_title': show_title
		}

	def _wetrakr_send(self, event, percent):
		if self.is_generic or not st.wetrakr_user_active(): return
		from apis.wetrakr_api import wetrakr_should_scrobble, wetrakr_send_event
		if not wetrakr_should_scrobble(): return
		kwargs = self._wetrakr_meta_kwargs(percent)
		self._spawn(wetrakr_send_event, args=(event, self.media_type), kwargs=kwargs, name='wetrakr_%s' % event)

	def _wetrakr_scrobble_start(self):
		self._wetrakr_scrobbled = False
		self._wetrakr_last_progress_send = 0
		percent = self.playback_percent if self.playback_percent else 0
		self._wetrakr_send('playing', percent)

	def _wetrakr_progress_tick(self):
		if self.is_generic or getattr(self, '_wetrakr_scrobbled', False): return
		if not st.wetrakr_user_active(): return
		from apis.wetrakr_api import wetrakr_should_scrobble, wetrakr_scrobble_threshold
		if not wetrakr_should_scrobble(): return
		now = time.time()
		last = getattr(self, '_wetrakr_last_progress_send', 0) or 0
		if now - last >= 30:
			self._wetrakr_last_progress_send = now
			self._wetrakr_send('playing', self.current_point)
		threshold = wetrakr_scrobble_threshold()
		if self.current_point >= threshold and not getattr(self, '_wetrakr_scrobbled', False):
			self._wetrakr_scrobbled = True
			self._wetrakr_send('scrobble', self.current_point)

	def _wetrakr_on_stop(self, percent, force_scrobble=False):
		if getattr(self, '_wetrakr_scrobbled', False): return
		from apis.wetrakr_api import wetrakr_scrobble_threshold
		threshold = wetrakr_scrobble_threshold()
		if force_scrobble or percent >= threshold:
			self._wetrakr_scrobbled = True
			self._wetrakr_send('scrobble', 100 if force_scrobble else percent)
		elif percent >= 5:
			self._wetrakr_send('paused', percent)

	def _maybe_write_resume_checkpoint(self):
		"""Every _RESUME_CHECKPOINT_INTERVAL_SEC, persist a local-only resume point (#58).
		Without this the bookmark exists solely after a graceful stop, so a crash or
		force-stop (this Shield's recurring SIGSEGV, #12; deploy hard kills) loses the
		whole episode's progress. Same 5-90% window as the stop-time bookmark; skipped
		once the media is marked watched."""
		try:
			if self.media_marked: return
			if not 5 <= self.current_point < 90: return
			now = time.time()
			if now - getattr(self, '_resume_checkpoint_written_at', 0) < _RESUME_CHECKPOINT_INTERVAL_SEC: return
			self._resume_checkpoint_written_at = now
			progress_params = {'media_type': self.media_type, 'tmdb_id': self.tmdb_id, 'curr_time': self.curr_time, 'total_time': self.total_time,
							'title': self.title, 'season': self.season, 'episode': self.episode, 'from_playback': 'true'}
			self._spawn(self.run_media_progress, args=(ws.set_bookmark_checkpoint, progress_params), name='bookmark_checkpoint')
		except: pass

	def media_watched_marker(self, force_watched=False):
		self.media_marked = True
		try:
			current_point = getattr(self, 'current_point', 0) or 0
			if current_point >= 90 or force_watched:
				self._trakt_scrobble_stop(100)
				self._simkl_scrobble_stop(100)
				self._punchplay_scrobble_stop(100)
				self._wetrakr_on_stop(100, force_scrobble=True)
				watched_function = ws.mark_movie if self.media_type == 'movie' else ws.mark_episode
				watched_params = {'action': 'mark_as_watched', 'tmdb_id': self.tmdb_id, 'title': self.title, 'year': self.year, 'season': self.season, 'episode': self.episode,
									'tvdb_id': self.tvdb_id, 'from_playback': 'true'}
				self._spawn(self.run_media_progress, args=(watched_function, watched_params), name='mark_watched')
				if self.media_type == 'episode':
					self._mark_combined_release_siblings_watched(watched_params)
			else:
				# Always stop Trakt live scrobble so Playing now clears. Below ~80% Trakt treats stop as pause + resume.
				self._trakt_scrobble_stop(current_point)
				self._simkl_scrobble_stop(current_point)
				self._punchplay_scrobble_stop(current_point)
				self._wetrakr_on_stop(current_point)
				ku.clear_property('redlight.random_episode_history')
				if current_point >= 5:
					progress_params = {'media_type': self.media_type, 'tmdb_id': self.tmdb_id, 'curr_time': self.curr_time, 'total_time': self.total_time,
									'title': self.title, 'season': self.season, 'episode': self.episode, 'from_playback': 'true'}
					self._spawn(self.run_media_progress, args=(ws.set_bookmark, progress_params), name='set_bookmark')
		except: pass

	def _mark_combined_release_siblings_watched(self, primary_watched_params):
		"""A combined-file release (e.g. a S03E17E18 double episode in one file) only reports
		its primary episode to watched_status. Mark every other same-season episode named in
		the release's own filename watched too, so 'next episode' logic doesn't re-surface the
		other half as unwatched."""
		try:
			from modules.source_utils import iter_season_episode_tokens
			release_name = getattr(self, 'playing_filename', '') or ku.get_property('subs.player_filename')
			if not release_name: return
			tokens = list(iter_season_episode_tokens(release_name))
			# Only trust the file's own numbering when it agrees with ours about the episode that
			# just played. A file matched by its title (#89) can carry another scheme's numbers
			# (DVD-order "S04E20 The Handicap Spot" playing as raw S04E22); its tokens then name
			# unrelated episodes, not siblings, and marking them would repeat #80's false marks.
			if not any(season == self.season and episode == self.episode for season, episode in tokens): return
			for season, episode in tokens:
				if season != self.season or episode == self.episode: continue
				sibling_params = dict(primary_watched_params)
				sibling_params['season'], sibling_params['episode'] = season, episode
				self._spawn(self.run_media_progress, args=(ws.mark_episode, sibling_params), name='mark_sibling_watched')
		except: pass

	def run_media_progress(self, function, params):
		try: function(params)
		except: pass

	def _valid_playback_duration(self, total_time=None, curr_time=None):
		try:
			total = total_time if total_time is not None else self.getTotalTime()
			curr = curr_time if curr_time is not None else self.getTime()
			if total in (0, 0.0, '0.0', '', None): return False
			if curr in (0, 0.0, '0.0', '', None): return False
			if float(total) < 60: return False
			return float(curr) > 0
		except:
			return False

	def _player_is_active(self):
		try:
			return self.isPlayingVideo() or self.isPlaying()
		except:
			return False

	def seek(self, seconds, pause_after=False):
		try:
			if not self._player_is_active():
				return False
			seconds = float(seconds)
			total = float(self.getTotalTime())
			if total > 1:
				seconds = max(0.0, min(seconds, total - 1.0))
			self.seekTime(seconds)
			if pause_after:
				self.pause()
			return True
		except:
			return False

	def _log_nextep(self, message):
		try: ku.logger('Red Light', message)
		except: pass

	def _intro_skip_play_type_label(self):
		try:
			play_type = getattr(self.sources_object, 'play_type', '') if getattr(self, 'sources_object', None) else ''
			if play_type in ('autoplay_nextep', 'autoscrape_nextep', 'random_continual'):
				return play_type
		except: pass
		return 'manual'

	def _log_intro_skip(self, message):
		try: ku.logger('Red Light', '%s (play_type=%s)' % (message, self._intro_skip_play_type_label()))
		except: pass

	def _defer_nextep_info(self):
		if getattr(self, 'nextep_info_gathered', False): return False
		nextep_settings = st.auto_nextep_settings(self._nextep_play_type())
		alert_timing = nextep_settings.get('alert_timing')
		if alert_timing == 'introdb':
			if self._outro_credits_pop_at(fetch=False) is not None: return False
			if self._outro_credits_pop_at(fetch=True) is not None: return False
			started = getattr(self, '_playback_started_at', None)
			if started and (time.time() - started) > _NEXTEP_SUB_FETCH_DEFER_SEC: return False
			return True
		if alert_timing != 'subtitles': return False
		if self._subtitle_end_remaining(fetch=False, for_alert=True) is not None: return False
		if not st.subs_alert_fetch_enabled(self.media_type): return False
		if getattr(self, '_subtitle_alert_fetch_done', False): return False
		started = getattr(self, '_playback_started_at', None)
		if started and (time.time() - started) > _NEXTEP_SUB_FETCH_DEFER_SEC: return False
		return True

	def decline_nextep_prep(self, reason=''):
		ku.set_property(PROP_NEXTEP_PREP_DECLINED, 'true')
		if reason:
			self._log_nextep('Next episode prep declined: %s' % reason)

	def _playback_meta_key(self):
		if getattr(self, 'is_generic', False):
			return None
		try:
			return '%s_%s_%s' % (self.tmdb_id, int(self.season), int(self.episode))
		except:
			return None

	def _owns_active_playback(self):
		try:
			if not self.isPlayingVideo():
				return False
			active = ku.get_property(PROP_ACTIVE_PLAYBACK_KEY)
			mine = self._playback_meta_key()
			if not active or not mine:
				return True
			return active == mine
		except:
			return False

	def _register_active_playback(self):
		key = self._playback_meta_key()
		if key:
			ku.set_property(PROP_ACTIVE_PLAYBACK_KEY, key)

	def _release_active_playback(self):
		key = self._playback_meta_key()
		if key and ku.get_property(PROP_ACTIVE_PLAYBACK_KEY) == key:
			ku.clear_property(PROP_ACTIVE_PLAYBACK_KEY)

	def _should_prep_next_ep(self):
		if not self._owns_active_playback():
			return False
		if getattr(self, '_nextep_stash_play_scheduled', False):
			return False
		if ku.get_property(PROP_NEXTEP_PREP_DECLINED) == 'true':
			return False
		if getattr(self, '_nextep_prep_attempted', False):
			return False
		if ku.get_property(PROP_NEXTEP_AUTOPLAY_CANCELLED) == 'true':
			return False
		if ku.get_property(PROP_NEXTEP_PENDING) == 'true':
			return False
		if ku.get_property(PROP_NEXTEP_PREP_SCHEDULED) == 'true':
			return False
		if self.autoplay_nextep and ku.get_property('redlight.nextep_scrape_ready') == 'true':
			try:
				from modules.sources import peek_nextep_autoplay_stash
				if peek_nextep_autoplay_stash():
					return False
			except:
				pass
		if not self._valid_playback_duration(self.total_time, self.curr_time):
			return False
		try:
			remaining = round(float(self.total_time) - float(self.curr_time))
		except:
			return False
		# start_prep is set by info_next_ep(), which _defer_nextep_info() holds back while the
		# introdb/subtitle timing is fetched (about 40 s on the Shield); until then there is no
		# prep point to reach, and reading the attribute raised on every play's first tick.
		start_prep = getattr(self, 'start_prep', None)
		if start_prep is None: return False
		if remaining > 0 and remaining <= start_prep: return True
		return self._early_prep_due(remaining, start_prep)

	def _maybe_early_stage2(self):
		"""Early prep stage 2: stage 1 (folders only) found nothing, so about a minute in run the full
		prep (cloud rungs too). Still no pre-resolve and nothing marked watched."""
		if not getattr(self, '_nextep_early_prep', False) or getattr(self, '_early_stage2', False): return
		if ku.get_property('redlight.nextep_stage1_miss') != 'true': return
		if ku.get_property(PROP_NEXTEP_PENDING) == 'true': return
		try:
			if float(self.curr_time) < _EARLY_STAGE2_SEC: return
			remaining = float(self.total_time) - float(self.curr_time)
		except Exception: return
		if remaining <= (getattr(self, 'start_prep', None) or 0): return
		self._early_stage2 = True
		self._nextep_prep_attempted = False
		self._log_nextep('Next episode early prep: stage 2 (folders found nothing)')
		self._schedule_next_ep()

	def _maybe_early_warm(self):
		"""The 2 MB warm read an early prep deferred: about a minute in, for a network file only."""
		if not getattr(self, '_nextep_early_prep', False) or getattr(self, '_early_warm_done', False): return
		queued = getattr(self, '_queued_real', None)
		if not queued: return
		try:
			if float(self.curr_time) < _EARLY_STAGE2_SEC: return
		except Exception: return
		self._early_warm_done = True
		url = queued.get('url')
		def _warm():
			try:
				from modules import nextep_warm
				if not nextep_warm.settings.nextep_warm_read(): return
				if not nextep_warm.is_network_path(url):
					ku.logger('Red Light', 'NextEpWarm: early, local folder, nothing to warm')
					return
				got, ms, err = nextep_warm.warm_read(url)
				ku.logger('Red Light', 'NextEpWarm: origin=early warm=%s bytes=%s ms=%s%s' % ('ok' if got else 'fail', got, ms, (' err=%s' % err) if err else ''))
				if not got: self._reprep_off_failed_provider(url)
			except Exception as exc:
				ku.logger('Red Light', 'NextEpWarm: early warm failed: %s' % exc)
		self._spawn(_warm, name='nextep_early_warm', daemon=True)

	def _reprep_off_failed_provider(self, url):
		"""#1 C447: the queued file did not answer its warm read (an RD 503, a broken link). Re-prepare
		now, preferring another provider, rather than find out at the jump."""
		if getattr(self, '_avoid_family', None): return  # once per play
		try:
			from modules.sources import debrid_family, take_nextep_autoplay_stash
			self._avoid_family = debrid_family({'url_dl': url})
			self._drop_queued_real('warm read failed')
			take_nextep_autoplay_stash(clear_only=True)
		except Exception as exc:
			ku.logger('Red Light', 'Next episode: re-prep after a failed warm read failed: %s' % exc)
			return
		self._nextep_early_prep, self._early_stage2, self._nextep_prep_attempted = True, True, False
		self._log_nextep('Next episode: warm read failed on %s, preparing again with another provider' % self._avoid_family)
		self._schedule_next_ep()

	def _early_prep_due(self, remaining, start_prep):
		"""#1: prepare the next episode early (setting Prepare Next Episode: Early, the default), once
		this one is settled: _EARLY_PREP_SEC in, the Skip Intro prompt answered or not coming, and no
		seek in the last _EARLY_PREP_SEEK_QUIET_SEC. It is the same prep as near the end (folders
		first, then cloud, a pre-resolve only for a non-folders top pick, the 2 MB warm read), just
		sooner, so every jump and the Next Up hand-off find it ready. Nothing is marked watched."""
		if not self.autoplay_nextep or not st.nextep_prep_early(): return False
		try: curr = float(self.curr_time)
		except Exception: return False
		if curr < _EARLY_PREP_SEC or remaining <= start_prep: return False
		last_seek = getattr(self, '_last_seek', None)
		if isinstance(last_seek, tuple) and time.time() - last_seek[0] < _EARLY_PREP_SEEK_QUIET_SEC: return False
		self._nextep_early_prep = True
		return True

	def _nextep_play_type(self):
		return 'autoplay_nextep' if self.autoplay_nextep else 'autoscrape_nextep'

	def _still_watching_due(self, nextep_settings):
		watching_check = nextep_settings.get('watching_check', 0)
		return watching_check and self.meta_get('watch_count') == watching_check

	def _pop_window_seconds(self, nextep_settings, total_time):
		return self._alert_window_time(nextep_settings, 90, total_time, still_watching_check=0)

	def _start_prep_seconds(self, nextep_settings, pop_at, play_type, include_still_watching=True):
		still_watching_due = self._still_watching_due(nextep_settings) if include_still_watching else False
		pipeline = st.nextep_pipeline_headroom(play_type, nextep_settings['scraper_time'], still_watching_due)
		return int(pop_at) + pipeline

	def _resolve_subtitle_pop_at(self, sub_tail, credits_entry):
		# subtitles.py returns the target remaining seconds; do not clamp to NEXTEP_ALERT_MAX (that cap is for % fallback only).
		vals = [int(v) for v in (sub_tail, credits_entry) if v is not None]
		if not vals: return None
		return max(max(vals), st.NEXTEP_ALERT_MIN_REMAINING_SEC)

	def _subtitle_credits_entry_remaining(self, fetch=False, quiet=False):
		if getattr(self, 'is_generic', False) or not getattr(self, 'imdb_id', None): return None
		if quiet:
			cached = getattr(self, '_subtitle_credits_entry_cached', '__unset__')
			if cached != '__unset__': return cached
		try:
			from indexers.subtitles import subtitle_seconds_remaining_before_end
			season = self.season if self.media_type == 'episode' else None
			episode = self.episode if self.media_type == 'episode' else None
			remaining = subtitle_seconds_remaining_before_end(float(self.total_time), self.imdb_id, season, episode, fetch=fetch,
				player=self, playing_filename=getattr(self, 'playing_filename', None), playing_item=getattr(self, 'playing_item', None),
				playback_started_at=getattr(self, '_playback_started_at', None),
				year=getattr(self, 'year', None), credits_entry=True, quiet=quiet)
		except:
			remaining = None
		if quiet: self._subtitle_credits_entry_cached = remaining
		return remaining

	def _ensure_random_continual_prep(self):
		if getattr(self, 'random_continual_start_prep', None) is not None: return
		if st.autoscrape_next_episode(): play_type = 'autoscrape_nextep'
		elif st.autoplay_next_episode(): play_type = 'autoplay_nextep'
		else: play_type = 'autoscrape_nextep'
		nextep_settings = st.auto_nextep_settings(play_type)
		pop_at, _timing_source = self._pop_window_seconds(nextep_settings, self.total_time)
		# Headroom for Still Watching when Check Still Watching After X is enabled (Continual Random).
		include_still_watching = bool(nextep_settings.get('watching_check', 0))
		self.random_continual_start_prep = self._start_prep_seconds(nextep_settings, pop_at, play_type, include_still_watching)

	def _should_prep_random_continual(self):
		if getattr(self, 'random_continual_triggered', False): return False
		if not self._valid_playback_duration(self.total_time, self.curr_time): return False
		self._ensure_random_continual_prep()
		try: remaining = round(float(self.total_time) - float(self.curr_time))
		except: return False
		return remaining > 0 and remaining <= self.random_continual_start_prep

	def _play_next_after_seek_end(self, explicit=False):
		"""#199: a skip to the end jumps over the start_prep window, so no next episode was prepared
		and the natural-end hand-off has nothing to play. Work out the literal next episode the same
		way the prep does and start it as a fresh play (mode=playback.media, as a Next Episodes row
		does), so this play's own cleanup finishes independently."""
		# explicit: the user asked for the next episode (#199 C7), so neither the autoplay setting
		# nor an earlier prep (its stash was dropped when the play stopped) holds it back.
		if getattr(self, 'media_type', None) != 'episode': return
		if not explicit and (not getattr(self, 'autoplay_nextep', False) or getattr(self, '_nextep_prep_attempted', False)): return
		try:
			from modules.episode_tools import EpisodeTools
			from modules.settings import playback_key
			nextep_settings = dict(getattr(self, 'nextep_settings', None) or {})
			nextep_settings.setdefault('play_type', self._nextep_play_type())
			params = EpisodeTools(dict(self.meta), nextep_settings).next_episode_info()
			if not isinstance(params, dict):
				self._log_nextep('Skip to the end: no next episode to start (%s)' % params)
				return
			for key in ('background', 'nextep_settings', 'play_type'): params.pop(key, None)
			params['mode'] = 'playback.%s' % playback_key()
			self._log_nextep('Skip to the end: starting %s S%02dE%02d' % (
				self.meta_get('title', ''), int(params['season']), int(params['episode'])))
			ku.run_plugin(params)
		except Exception as exc:
			ku.logger('Red Light', 'Skip to the end: next episode start failed: %s' % exc)

	def _schedule_next_ep(self):
		if ku.get_property(PROP_NEXTEP_PENDING) == 'true':
			return
		if ku.get_property(PROP_NEXTEP_PREP_SCHEDULED) == 'true':
			return
		try: remaining = round(float(self.total_time) - float(self.curr_time))
		except: remaining = -1
		self._log_nextep('Next episode prep scheduled: %s S%02dE%02d play_type=%s remaining=%ss start_prep=%ss' % (
			self.meta_get('title', ''), self.meta_get('season', 0), self.meta_get('episode', 0),
			self.nextep_settings.get('play_type', ''), remaining, getattr(self, 'start_prep', '')))
		self._nextep_prep_attempted = True
		ku.set_property(PROP_NEXTEP_PREP_SCHEDULED, 'true')
		ku.set_property(PROP_NEXTEP_PENDING, 'true')
		meta = dict(self.meta) if getattr(self, 'meta', None) else {}
		nextep_settings = dict(self.nextep_settings) if getattr(self, 'nextep_settings', None) else None
		early = getattr(self, '_nextep_early_prep', False)
		if nextep_settings is not None and getattr(self, '_avoid_family', None):
			nextep_settings['avoid_family'] = self._avoid_family
		if early and nextep_settings is not None:
			nextep_settings['early_prep'] = True
			# Stage 1 is the folders-only look (cached listing, no debrid API); stage 2 is full.
			nextep_settings['folders_only'] = not getattr(self, '_early_stage2', False)
			ku.clear_property('redlight.nextep_stage1_miss')
		def _work():
			try:
				from modules.episode_tools import EpisodeTools
				if not early and not self.media_marked:
					try: self.media_watched_marker(force_watched=True)
					except: pass
				EpisodeTools(meta, nextep_settings).auto_nextep()
			except Exception as exc:
				ku.logger('Red Light', 'Next episode prep failed: %s' % exc)
			finally:
				ku.clear_property(PROP_NEXTEP_PENDING)
				ku.clear_property(PROP_NEXTEP_PREP_SCHEDULED)
		self._spawn(_work, name='nextep_prep', daemon=True)

	def _maybe_log_nextep_alert_pending(self):
		if not self.autoplay_nextep or getattr(self, '_nextep_alert_shown', False): return
		if not self._owns_active_playback(): return
		if getattr(self, '_nextep_alert_pending_logged', False): return
		if ku.get_property('redlight.nextep_scrape_ready') != 'true': return
		try:
			from modules.sources import peek_nextep_autoplay_stash
			if not peek_nextep_autoplay_stash(): return
		except:
			return
		try:
			remaining = round(float(self.total_time) - float(self.curr_time))
		except:
			return
		window = int(getattr(self, 'nextep_settings', {}).get('window_time', 0) or 0)
		if remaining <= 0 or remaining <= window: return
		self._nextep_alert_pending_logged = True
		self._log_nextep('Autoplay next episode alert pending: remaining=%ss window=%ss (scrape ready)' % (remaining, window))

	def _should_show_autoplay_nextep_alert(self):
		if not self.autoplay_nextep or not getattr(self, 'nextep_settings', None): return False
		if getattr(self, '_osd_nextup_open', False): return False  # C428 dialog up; the alert waits a tick
		if getattr(self, '_nextep_alert_shown', False): return False
		if not self._owns_active_playback():
			return False
		try:
			from modules.sources import nextep_autoplay_cancelled, peek_nextep_autoplay_stash, nextep_alert_handled, PROP_NEXTEP_SCRAPE_KEY
			if nextep_autoplay_cancelled(): return False
			key = ku.get_property(PROP_NEXTEP_SCRAPE_KEY)
			if nextep_alert_handled(key):
				self._nextep_alert_shown = True
				return False
		except:
			pass
		if ku.get_property('redlight.nextep_scrape_ready') != 'true': return False
		try:
			from modules.sources import peek_nextep_autoplay_stash
			if not peek_nextep_autoplay_stash(): return False
		except:
			return False
		try:
			remaining = round(float(self.total_time) - float(self.curr_time))
		except:
			return False
		window = int(self.nextep_settings.get('window_time', 0) or 0)
		return remaining > 0 and remaining <= window

	def _try_autoscrape_nextep_ready_notify(self):
		if not self.autoscrape_nextep or getattr(self, '_autoscrape_ready_notified', False): return
		if not self._owns_active_playback(): return
		if not ku.get_property(PROP_AUTOSCRAPE_NEXTEP_READY): return
		if not getattr(self, 'nextep_settings', None): return
		try:
			remaining = round(float(self.total_time) - float(self.curr_time))
		except:
			return
		window = int(self.nextep_settings.get('window_time', 0) or 0)
		if remaining <= 0 or remaining > window: return
		self._autoscrape_ready_notified = True
		meta = {}
		try:
			raw = ku.get_property(PROP_AUTOSCRAPE_NEXTEP_READY)
			if raw and raw != 'true':
				meta = json.loads(raw)
		except:
			pass
		ku.clear_property(PROP_AUTOSCRAPE_NEXTEP_READY)
		ku.set_property(ku.PROP_AUTOSCRAPE_TOAST_SHOWN, 'true')
		title = meta.get('title') or self.meta_get('title', '')
		season = meta.get('season', self.season)
		episode = meta.get('episode', self.episode)
		poster = meta.get('poster') or self.meta_get('poster')
		ku.notification('[B]Next Episode Ready:[/B] %s S%02dE%02d' % (title, season, episode), 6500, poster)
		self._log_nextep('Autoscrape next episode ready notify: remaining=%ss window=%ss' % (remaining, window))

	def _try_autoplay_early_stash_play(self):
		if not self.autoplay_nextep or not getattr(self, '_nextep_close_wait', False):
			return
		if getattr(self, '_queued_real', None): return  # end-keep: Kodi flows on into the queued file
		if not self._owns_active_playback():
			return
		if getattr(self, '_nextep_stash_play_scheduled', False) or not getattr(self, '_nextep_alert_shown', False):
			return
		try:
			from modules.sources import nextep_autoplay_cancelled, nextep_end_play_superseded, peek_nextep_autoplay_stash, schedule_nextep_stashed_play, take_nextep_autoplay_stash
			if nextep_autoplay_cancelled() or nextep_end_play_superseded() or not peek_nextep_autoplay_stash():
				return
		except:
			return
		try:
			remaining = round(float(self.total_time) - float(self.curr_time))
		except:
			return
		if remaining > _NEXTEP_CLOSE_EARLY_PLAY_SEC or remaining <= 0:
			return
		stash = take_nextep_autoplay_stash()
		if not stash:
			return
		if schedule_nextep_stashed_play(stash, show_busy=False):
			self._nextep_stash_play_scheduled = True
			self._log_nextep('Autoplay next episode: early stash resolve at remaining=%ss' % remaining)

	def _play_with_queued_next(self, listitem):
		"""#199 C6: an episode plays as item 0 of Kodi's video playlist with a marker for the next
		episode as item 1, so the remote's plain Next key has somewhere to go (a single-item play only
		walks chapters). The marker is a plugin URL, not a stream; nothing is resolved ahead."""
		if self.is_generic or getattr(self, 'media_type', None) != 'episode': return False
		try:
			playlist = ku.make_playlist('video')
			playlist.clear()
			playlist.add(self.url, listitem)
			marker = xbmcgui.ListItem(label='Next episode', offscreen=True)
			marker.setProperty('IsPlayable', 'true')
			playlist.add(ku.build_url({'mode': QUEUED_NEXT_MODE}), marker)
			self.play(playlist)
			self._own_index = 0
		except Exception as exc:
			ku.logger('Red Light', 'Queued next episode: playlist play failed, playing alone: %s' % exc)
			try: ku.clear_video_playlist()
			except Exception: pass
			return False
		self._queued_next = True
		return True

	def _own_playlist_index(self):
		idx = getattr(self, '_own_index', None)
		return idx if isinstance(idx, int) else 0

	def _maybe_queue_real_next(self):
		"""#1 C417: once the next episode is stashed, swap the queued marker for its real file, so the
		remote's Next key makes Kodi play it straight away (no stop, no home screen). Only for a file
		that plays as is: a zurg/folders path, or a fresh pre-resolve. The stash stays in place, so
		the Next Up dialog and the natural-end hand-off are unchanged; the marker drop 20 s before the
		end removes this item the same way."""
		if getattr(self, '_queued_real', None): return
		if not getattr(self, '_queued_next', False) and not getattr(self, '_force_queue', False): return
		if not getattr(self, 'autoplay_nextep', False): return
		try:
			from modules.sources import nextep_autoplay_cancelled, peek_nextep_autoplay_stash, nextep_preresolve_is_fresh
			if nextep_autoplay_cancelled(): return
			stash = peek_nextep_autoplay_stash()
			if not stash or not stash.get('results'): return
			top = stash['results'][0]
			preresolved = stash.get('preresolved')
			if preresolved and nextep_preresolve_is_fresh(preresolved, top): url = preresolved['url']
			elif top.get('scrape_provider') == 'folders' and top.get('url_dl'): url = top['url_dl']
			else: return
			meta = stash.get('meta') or {}
			season, episode = int(meta.get('season', 0) or 0), int(meta.get('episode', 0) or 0)
			listitem = xbmcgui.ListItem(label='%s - %sx%02d' % (meta.get('title', ''), season, episode), offscreen=True)
			try:
				tag = listitem.getVideoInfoTag()
				tag.setMediaType('episode')
				tag.setTvShowTitle(meta.get('title', '') or '')
				tag.setTitle(meta.get('ep_name', '') or '')
				tag.setSeason(season)
				tag.setEpisode(episode)
				listitem.setArt({'poster': meta.get('poster', ''), 'fanart': meta.get('fanart', ''), 'thumb': meta.get('ep_thumb') or meta.get('fanart', '')})
				# Kodi resumes by file name; Red Light decides resume itself (C420 seek after adopt).
				self._disable_kodi_url_resume(listitem)
			except Exception: pass
			playlist = ku.make_playlist('video')
			marker_index = self._own_playlist_index() + 1
			if playlist.size() > marker_index: playlist.remove(ku.build_url({'mode': QUEUED_NEXT_MODE}))
			playlist.add(url, listitem, marker_index)
		except Exception as exc:
			ku.logger('Red Light', 'Queued next episode: real file swap failed: %s' % exc)
			return
		self._queued_real = {'url': url, 'index': marker_index}
		self._log_nextep('Queued next episode: %s S%02dE%02d queued as its file, the Next key plays it directly' % (
			meta.get('title', ''), season, episode))

	def _maybe_osd_nextup(self):
		"""#1 C428: with the OSD open and the next episode prepared, show Red Light's Next Up dialog
		(OSD mode: no countdown, closes with the OSD). It runs on its own thread so this monitor, and
		the skip claim, never wait on it (the pd.87 lesson). Play is a skip: the one jump path."""
		osd = ku.get_visibility('Window.IsVisible(videoosd)')
		if not osd:
			self._osd_nextup_seen = False
			return
		if getattr(self, '_osd_nextup_seen', False) or getattr(self, '_osd_nextup_open', False): return
		if getattr(self, '_nextep_alert_shown', False): return
		if ku.get_property(PROP_SKIP_EPISODE) == 'true' or getattr(self, '_skip_prep_deadline', None): return
		# Not in the first seconds of a play, and never over the Skip Intro prompt.
		try:
			if float(self.curr_time) < 10: return
		except Exception: return
		if getattr(self, '_intro_skip_active', False) and not getattr(self, '_intro_skip_done', False): return
		finding = False
		try:
			from modules.sources import peek_nextep_autoplay_stash
			stash = peek_nextep_autoplay_stash()
			meta = dict((stash or {}).get('meta') or {})
		except Exception: return
		if not meta:
			# Nothing prepared yet but the prep is running: show the dialog in its Finding Source state.
			if ku.get_property(PROP_NEXTEP_PENDING) != 'true': return
			finding, meta = True, self._next_meta_guess()
			if not meta: return
		ready, info_line = bool(getattr(self, '_queued_real', None)), self._nextup_info_line(stash)
		self._osd_nextup_seen, self._osd_nextup_open = True, True
		def _show():
			try:
				from windows.base_window import open_window
				action = open_window(('windows.playback_notifications', 'NextEpisode'), 'playback_notifications.xml', meta=meta, default_action='close', osd_mode=True,
					ready=ready, info_line=info_line, finding=finding)
				self._log_nextep('OSD Next Up: %s' % (action or 'close'))
				if action == 'play': ku.set_property(PROP_SKIP_EPISODE, 'true')
			except Exception as exc:
				ku.logger('Red Light', 'OSD Next Up failed: %s' % exc)
			finally:
				self._osd_nextup_open = False
		self._spawn(_show, name='osd_nextup', daemon=True)

	def _next_meta_guess(self):
		"""Title and SxxEyy for the Finding Source state, before the prep has stashed the real meta."""
		try:
			meta = dict(self.meta)
			meta.update({'season': int(self.meta_get('season')), 'episode': int(self.meta_get('episode')) + 1, 'ep_name': ''})
			return meta
		except Exception: return None

	@staticmethod
	def _nextup_info_line(stash):
		"""'4K DV · 22 min' from the stash's top result and the episode's runtime."""
		try:
			top = ((stash or {}).get('results') or [{}])[0]
			parts = [top.get('quality') or '']
			extra = (top.get('extraInfo') or '').upper()
			for tag in ('DV', 'HDR10+', 'HDR'):
				if tag in extra.replace('DOLBY VISION', 'DV').split(' | ') or (' %s ' % tag) in (' %s ' % extra.replace('|', ' ')):
					parts.append(tag); break
			duration = int(((stash or {}).get('meta') or {}).get('duration') or 0)
			if duration: parts.append('%d min' % round(duration / 60.0))
			return '  ·  '.join(p for p in parts if p)
		except Exception: return ''

	def _update_nextep_ready_flag(self):
		ready, label = False, ''
		if self.media_type == 'episode' and getattr(self, 'autoplay_nextep', False):
			try:
				from modules.sources import nextep_autoplay_cancelled, peek_nextep_autoplay_stash
				stash = None if nextep_autoplay_cancelled() else peek_nextep_autoplay_stash()
				if stash:
					meta = stash.get('meta') or {}
					ready = True
					label = 'S%02dE%02d %s' % (int(meta.get('season', 0) or 0), int(meta.get('episode', 0) or 0), meta.get('ep_name', '') or '')
			except Exception: ready = False
		if ready == getattr(self, '_nextep_ready_shown', False) and label == getattr(self, '_nextep_ready_label', ''): return
		self._nextep_ready_shown, self._nextep_ready_label = ready, label
		if ready:
			ku.set_property(PROP_NEXTEP_READY_LABEL, label.strip())
			ku.set_property(PROP_NEXTEP_READY, 'true')
		else:
			ku.clear_property(PROP_NEXTEP_READY)
			ku.clear_property(PROP_NEXTEP_READY_LABEL)

	def _maybe_requeue_before_end(self):
		"""By the near-end prep point the next file should be queued, so the natural end flows into it
		like every other jump. If the stash's top pick could not be queued, re-prepare it once."""
		if getattr(self, '_queued_real', None) or getattr(self, '_requeue_tried', False): return
		if not getattr(self, 'autoplay_nextep', False) or ku.get_property(PROP_NEXTEP_PENDING) == 'true': return
		try:
			from modules.sources import peek_nextep_autoplay_stash
			if not peek_nextep_autoplay_stash(): return
			remaining = float(self.total_time) - float(self.curr_time)
		except Exception: return
		start_prep = getattr(self, 'start_prep', None)
		if start_prep is None or remaining > start_prep: return
		self._requeue_for_preresolve('near the end')

	def _queued_real_advanced(self):
		"""Kodi moved onto the real next file this play queued (the Next key)."""
		if getattr(self, '_advanced_to_queued', False): return True
		if getattr(self, '_premature_end', False): return False
		queued = getattr(self, '_queued_real', None)
		if not queued: return False
		try: moved = ku.make_playlist('video').getposition() == queued['index']
		except Exception: return False
		if not moved: return False
		try: remaining = float(self.total_time) - float(self.curr_time)
		except Exception: remaining = None
		if getattr(self, '_stepping', False):
			why = 'skip or Next Up, Kodi is playing the queued file'
		elif remaining is not None and remaining <= _NEXTEP_NATURAL_END_SEC * 2:
			why = 'natural end, Kodi moved to the queued file'
		elif getattr(self, '_cb_ended', False) and remaining is not None and remaining > _PREMATURE_END_SEC:
			# C447 (Shield 29.09 10:15): the RD stream broke 3 minutes in, Kodi read the demuxer EOF
			# as the end and moved on to the queued file. Not an end: take Kodi back off the queued
			# file and let the stall handling reopen this episode at its position.
			self._premature_end = True
			ku.logger('Red Light', 'Playback ended %.0fs before the end (stream failure, not a natural end): '
				'not moving on, reopening this episode' % remaining)
			self._drop_queued_real('premature end')
			try: self.stop()
			except Exception: pass
			return False
		else:
			why = 'Next key, Kodi is playing the queued file'
		self._advanced_to_queued = True
		self._log_nextep('Play next episode now: %s' % why)
		return True

	def _hand_over_to_queued_real(self):
		"""Kodi already plays the next episode. Schedule its stash play, which adopts that file as a
		normal Red Light play (ownership, intro skip, Next Up and the prep after it, subtitles, the
		rewatch cursor) instead of opening it again."""
		try:
			from modules.sources import nextep_preresolve_item_key, schedule_nextep_stashed_play, take_nextep_autoplay_stash
			stash = take_nextep_autoplay_stash()
			if not stash: return False
			queued = self._queued_real or {}
			top = (stash.get('results') or [None])[0]
			stash['preresolved'] = {'url': queued.get('url'), 'item_key': nextep_preresolve_item_key(top), 'resolved_at': time.time()}
			ku.set_property(PROP_ADOPT_QUEUED, 'true')
			if schedule_nextep_stashed_play(stash, show_busy=False, adopting=True): return True
			ku.logger('Red Light', 'Queued next episode: adopt hand-over was refused; the episode plays on without Red Light')
			ku.clear_property(PROP_ADOPT_QUEUED)
		except Exception as exc:
			ku.logger('Red Light', 'Queued next episode: adopt hand-over failed: %s' % exc)
			ku.clear_property(PROP_ADOPT_QUEUED)
		return False

	def _adopt_queued_play(self):
		"""The stash play for an episode Kodi is already playing (see _hand_over_to_queued_real): skip
		the open, put a marker behind it for the Next key, and let the open check confirm."""
		if ku.get_property(PROP_ADOPT_QUEUED) != 'true': return False
		ku.clear_property(PROP_ADOPT_QUEUED)
		if self.is_generic or getattr(self, 'media_type', None) != 'episode': return False
		try:
			if not self.isPlayingVideo(): return False
			playlist = ku.make_playlist('video')
			self._own_index = playlist.getposition()
			marker = xbmcgui.ListItem(label='Next episode', offscreen=True)
			marker.setProperty('IsPlayable', 'true')
			playlist.add(ku.build_url({'mode': QUEUED_NEXT_MODE}), marker)
		except Exception as exc:
			ku.logger('Red Light', 'Queued next episode: adopt failed, opening normally: %s' % exc)
			return False
		self._queued_next = True
		# Kodi sent this file's AV-start before this player existed; without it a user Stop would
		# read as a stall and reopen the episode (_note_abnormal_end).
		self._cb_started = True
		# Only a file that is really showing counts as started for the Stop-vs-failure call (C447):
		# a queued file still opening (an RD 503) that then stops is a failed open, not a user Stop.
		try: self._cb_avstarted = float(self.getTotalTime() or 0) > 0 and float(self.getTime() or 0) > 0
		except Exception: self._cb_avstarted = False
		self._log_nextep('Queued next episode: adopted the playing file as this Red Light play')
		return True

	def _adopt_resume_seek(self):
		try: percent = float(getattr(self.sources_object, 'playback_percent', 0) or 0)
		except Exception: percent = 0.0
		if percent <= 0: return
		try:
			target = float(self.getTotalTime()) * percent / 100.0
			if target > 5: self.seekTime(target)
			self._log_nextep('Queued next episode: resumed at %.0f%% (%.0fs)' % (percent, target))
		except Exception as exc:
			ku.logger('Red Light', 'Queued next episode: resume seek failed: %s' % exc)

	def _drop_queued_real(self, reason):
		"""Take the real next file off the playlist, so the episode ends without flowing into it."""
		queued = getattr(self, '_queued_real', None)
		if not queued: return
		self._queued_real = None
		self._queued_next = False
		try: ku.make_playlist('video').remove(queued['url'])
		except Exception as exc: ku.logger('Red Light', 'Queued next episode: removal failed: %s' % exc)
		self._log_nextep('Queued next episode: removed (%s)' % reason)

	def _maybe_drop_queued_next(self):
		if not getattr(self, '_queued_next', False): return
		# #1 end-keep: a real queued file stays to the end, so a natural end flows straight into it
		# (gapless autoplay, adopted like the Next key). It is removed only if the next episode is
		# cancelled. The plain marker still comes off 20 s before the end.
		if getattr(self, '_queued_real', None):
			try:
				from modules.sources import nextep_autoplay_cancelled
				if nextep_autoplay_cancelled(): self._drop_queued_real('next episode cancelled')
			except Exception: pass
			return
		try: remaining = float(self.getTotalTime()) - float(self.getTime())
		except Exception: return
		if not (0 < remaining <= _QUEUED_NEXT_DROP_SEC): return
		self._queued_next = False
		try:
			playlist = ku.make_playlist('video')
			queued = getattr(self, '_queued_real', None)
			self._queued_real = None
			if playlist.size() > self._own_playlist_index() + 1:
				playlist.remove(queued['url'] if queued else ku.build_url({'mode': QUEUED_NEXT_MODE}))
		except Exception as exc:
			ku.logger('Red Light', 'Queued next episode: marker removal failed: %s' % exc)

	def _queued_next_taken(self):
		if not getattr(self, '_queued_next', False): return False
		self._queued_next = False
		if ku.get_property(PROP_QUEUED_NEXT_HIT) == 'true':
			ku.clear_property(PROP_QUEUED_NEXT_HIT)
			return True
		try: return ku.make_playlist('video').getposition() == self._own_playlist_index() + 1
		except Exception: return False

	def _note_rewatch(self):
		"""#1 C407: keep the show's rewatch cursor (modules.rewatch_cursor) in step with this play."""
		try:
			from modules import watched_status as ws
			from modules.rewatch_cursor import on_play_started
			tmdb_id, season, episode = self.meta_get('tmdb_id'), self.meta_get('season'), self.meta_get('episode')
			watched = bool(ws.get_watched_status_episode(ws.watched_info_episode(tmdb_id), (int(season), int(episode))))
			done = on_play_started(tmdb_id, season, episode, watched, st.nextep_rewatch_continue())
			if done: ku.logger('Red Light', 'Rewatch cursor %s: tmdb=%s S%02dE%02d' % (done, tmdb_id, int(season), int(episode)))
		except Exception as exc:
			ku.logger('Red Light', 'Rewatch cursor update failed: %s' % exc)

	def _try_skip_to_stash(self):
		"""#1: the explicit next-episode skip (request_skip_episode, or the Next key's C6 marker path
		via the same flag) hands over from fullscreen, the way the Next Up dialog's Play does, so there
		is no stop and no home screen.

		Stash ready: mark this one watched and schedule the stashed play now. No stash yet (C410): claim
		the skip at once, start the next-episode prep in the background while this episode keeps
		playing, and hand over as soon as it stashes. Only when the prep ends without a stash, or takes
		longer than _SKIP_PREP_WAIT_SEC, does the skip fall back to the stop and fresh play."""
		if self.media_type != 'episode': return False
		if getattr(self, '_nextep_stash_play_scheduled', False): return False
		waiting = getattr(self, '_skip_prep_deadline', None)
		if not waiting and ku.get_property(PROP_SKIP_EPISODE) != 'true': return False
		if not getattr(self, 'autoplay_nextep', False):
			# Autoplay (or only autoscrape) is off: the skip is the request, so prepare this one next
			# episode the autoplay way (stash, then fullscreen hand-over) instead of stopping (#1).
			if getattr(self, '_skip_prep_allowed', False) is not True: return False
			self.autoplay_nextep, self.autoscrape_nextep = True, False
			self.nextep_info_gathered = False
			self._log_nextep('Play next episode now: autoplay is off, preparing this skip the autoplay way')
		try:
			from modules.sources import nextep_autoplay_cancelled, peek_nextep_autoplay_stash
			if nextep_autoplay_cancelled(): return self._skip_prep_fallback('next episode cancelled') if waiting else False
			ready = bool(peek_nextep_autoplay_stash())
		except Exception as exc:
			ku.logger('Red Light', 'Play next episode now: stash check failed: %s' % exc)
			return False
		if ready: return self._skip_hand_over()
		if waiting:
			prep_running = ku.get_property(PROP_NEXTEP_PENDING) == 'true'
			if not prep_running: return self._skip_prep_fallback('prep ended without a next episode')
			if time.time() > waiting: return self._skip_prep_fallback('prep took over %ss' % _SKIP_PREP_WAIT_SEC)
			return False
		# Claim the skip so request_skip_episode does not stop playback, then prepare on demand.
		ku.clear_property(PROP_SKIP_EPISODE)
		ku.set_property(PROP_SKIP_EPISODE_ACK, 'true')
		self._skip_prep_deadline = time.time() + _SKIP_PREP_WAIT_SEC
		ku.set_property(PROP_SKIP_PREP_WAITING, 'true')
		if not self.media_marked: self.media_watched_marker(force_watched=True)
		if not getattr(self, 'nextep_info_gathered', False):
			try: self.info_next_ep()
			except Exception as exc: ku.logger('Red Light', 'Play next episode now: next-episode settings failed: %s' % exc)
		if ku.get_property(PROP_NEXTEP_PENDING) != 'true':
			if getattr(self, 'nextep_settings', None): self._schedule_next_ep()
			else: return self._skip_prep_fallback('no next-episode settings')
		self._log_nextep('Play next episode now: preparing the next episode while this one plays')
		return True

	def _step_to_queued(self, why):
		"""#1 pd.98: the one way every jump moves on. Kodi steps its playlist onto the queued file (not
		a chapter step), the loop sees it and the next Red Light play adopts it. No resolve screen;
		one small toast while the file opens."""
		queued = self._queued_real or {}
		try:
			from modules.sources import peek_nextep_autoplay_stash
			meta = (peek_nextep_autoplay_stash() or {}).get('meta') or {}
			ku.notification('Next: %s S%02dE%02d' % (meta.get('title', ''), int(meta.get('season', 0) or 0), int(meta.get('episode', 0) or 0)), 2500)
		except Exception: pass
		self._stepping = True
		self.playnext()
		self._log_nextep('Play next episode now: moving Kodi on to the queued file (%s)' % why)

	def _requeue_for_preresolve(self, reason):
		"""The stash's top pick is a debrid item with no pre-resolve (an early prep skips it), so it
		cannot be queued as a file. Run the full prep once more (with the pre-resolve) while this
		episode plays, so it can be queued; the caller waits for it."""
		if getattr(self, '_requeue_tried', False): return False
		self._requeue_tried = True
		try:
			from modules.sources import take_nextep_autoplay_stash
			take_nextep_autoplay_stash(clear_only=True)
		except Exception: return False
		self._nextep_early_prep = False
		self._early_stage2 = True
		self._nextep_prep_attempted = False
		self._log_nextep('Next episode: re-preparing with a pre-resolve so it can be queued (%s)' % reason)
		self._schedule_next_ep()
		return True

	def _skip_hand_over(self):
		if not getattr(self, '_queued_real', None):
			self._force_queue = True
			self._maybe_queue_real_next()
		if not getattr(self, '_queued_real', None) and self._requeue_for_preresolve('skip'):
			# Keep playing and wait for the re-prep, exactly like an on-demand skip prep.
			ku.clear_property(PROP_SKIP_EPISODE)
			ku.set_property(PROP_SKIP_EPISODE_ACK, 'true')
			self._skip_prep_deadline = time.time() + _SKIP_PREP_WAIT_SEC
			ku.set_property(PROP_SKIP_PREP_WAITING, 'true')
			return True
		if getattr(self, '_queued_real', None):
			# The next file is already queued (#1): step Kodi's playlist onto it (a playlist step, not a
			# chapter step) and let the loop adopt it, with no resolve screen. The stash play below
			# stays the fallback for when nothing is queued.
			try:
				if not self.media_marked: self.media_watched_marker(force_watched=True)
				ku.clear_property(PROP_SKIP_EPISODE)
				ku.set_property(PROP_SKIP_EPISODE_ACK, 'true')
				self._skip_prep_deadline = None
				ku.clear_property(PROP_SKIP_PREP_WAITING)
				self._step_to_queued('skip')
				return True
			except Exception as exc:
				ku.logger('Red Light', 'Play next episode now: playnext failed, using the stash play: %s' % exc)
		try:
			from modules.sources import nextep_end_play_superseded, schedule_nextep_stashed_play, take_nextep_autoplay_stash
			if nextep_end_play_superseded(): return False
			stash = take_nextep_autoplay_stash()
			if not stash: return False
			if not self.media_marked: self.media_watched_marker(force_watched=True)
			if not schedule_nextep_stashed_play(stash, show_busy=False): return False
		except Exception as exc:
			ku.logger('Red Light', 'Play next episode now: stash hand-off failed: %s' % exc)
			return False
		self._nextep_stash_play_scheduled = True
		self._skip_prep_deadline = None
		ku.clear_property(PROP_SKIP_PREP_WAITING)
		ku.clear_property(PROP_SKIP_EPISODE)
		ku.set_property(PROP_SKIP_EPISODE_ACK, 'true')
		self._log_nextep('Play next episode now: playing the prepared next episode')
		return True

	def _skip_prep_fallback(self, reason):
		"""The on-demand prep could not produce a next episode: skip the old way (stop, then the end
		handling marks watched and starts a fresh play of the next episode)."""
		self._skip_prep_deadline = None
		ku.clear_property(PROP_SKIP_PREP_WAITING)
		self._log_nextep('Play next episode now: %s, stopping instead' % reason)
		ku.set_property(PROP_SKIP_EPISODE, 'true')
		try: self.stop()
		except Exception: pass
		return False

	def _try_autoplay_nextep_alert(self):
		if not self._should_show_autoplay_nextep_alert(): return
		try:
			from modules.sources import peek_nextep_autoplay_stash, take_nextep_autoplay_stash, claim_nextep_alert_handled, PROP_NEXTEP_SCRAPE_KEY
		except:
			return
		stash_key = ku.get_property(PROP_NEXTEP_SCRAPE_KEY)
		if not claim_nextep_alert_handled(stash_key):
			self._nextep_alert_shown = True
			return
		self._nextep_alert_shown = True
		stash = peek_nextep_autoplay_stash()
		if not stash: return
		settings = self.nextep_settings
		# Play # Episodes: silent chain — wait for natural end, then play stashed next.
		if settings.get('play_n_episodes'):
			self._nextep_close_wait = True
			self._log_nextep('Play # Episodes: silent continue (remaining after this=%s)' % settings.get('num_episodes'))
			return
		use_window = settings.get('use_window')
		default_action = settings.get('default_action')
		dialog_meta = stash['meta']
		try:
			remaining = round(float(self.total_time) - float(self.curr_time))
		except:
			remaining = settings.get('window_time')
		self._log_nextep('Autoplay next episode alert: remaining=%ss window=%ss method=%s' % (
			remaining, settings.get('window_time'), 'window' if use_window else 'notification'))
		action = None
		if use_window:
			from windows.base_window import open_window
			try:
				action = open_window(('windows.playback_notifications', 'NextEpisode'), 'playback_notifications.xml', meta=dialog_meta, default_action=default_action,
					ready=bool(getattr(self, '_queued_real', None)), info_line=self._nextup_info_line(stash))
			except:
				action = 'cancel'
		else:
			ku.notification('[B]Next Up:[/B] %s S%02dE%02d' % (dialog_meta.get('title'), dialog_meta.get('season'), dialog_meta.get('episode')), 6500, dialog_meta.get('poster'))
		if not action:
			action = default_action if use_window else 'close'
		if not action:
			action = 'close'
		if getattr(self, '_cb_stopped', False) and action == 'play':
			# #1 (W-280926-14): the user pressed Stop while Next Up was up. The dialog then returned
			# its default (Play) and the next episode started after a Stop. A Stop is a stop.
			self._log_nextep('Autoplay next episode alert: playback was stopped, not playing on')
			action = 'cancel'
		if action == 'cancel':
			try:
				from modules.sources import mark_nextep_autoplay_cancelled
				mark_nextep_autoplay_cancelled()
			except:
				pass
			ku.clear_property(PROP_NEXTEP_PREP_SCHEDULED)
			self._drop_queued_real('Next Up cancelled')
			self._log_nextep('Autoplay next episode alert action: cancel')
			return
		if action == 'pause':
			self._nextep_close_wait = True
			self._log_nextep('Autoplay next episode alert action: pause (waiting for user)')
			return
		if action == 'close':
			self._nextep_close_wait = True
			self._log_nextep('Autoplay next episode alert action: close (waiting for episode end)')
			return
		if action != 'play':
			return
		self._log_nextep('Autoplay next episode alert action: play')
		if self.media_type == 'episode' and getattr(self, 'autoplay_nextep', False):
			# pd.98: Next Up's Play is a skip like any other; the next tick runs the one jump path.
			ku.set_property(PROP_SKIP_EPISODE, 'true')
			return
		stash = take_nextep_autoplay_stash()
		if not stash: return
		try:
			from modules.sources import schedule_nextep_stashed_play
			if schedule_nextep_stashed_play(stash):
				self._nextep_stash_play_scheduled = True
			else:
				ku.logger('Red Light', 'Autoplay next episode play failed: could not schedule resolve')
		except Exception as exc:
			ku.logger('Red Light', 'Autoplay next episode play failed: %s' % exc)
		return

	def run_next_ep(self):
		from modules.episode_tools import EpisodeTools
		if not self.media_marked: self.media_watched_marker(force_watched=True)
		EpisodeTools(self.meta, self.nextep_settings).auto_nextep()

	def run_random_continual(self):
		from modules.episode_tools import EpisodeTools
		if not self.media_marked: self.media_watched_marker(force_watched=True)
		EpisodeTools(self.meta).play_random_continual(False)

	def run_movie_stingers(self):
		self.movie_stingers_run = True
		stinger_keys = self.meta.get('stinger_keys', None)
		if not stinger_keys:
			try:
				keywords = self.meta.get('keywords', [])
				stinger_keys = [i['name'] for i in keywords['keywords'] if i['name'] in ('duringcreditsstinger', 'aftercreditsstinger')]
				self.meta['stinger_keys'] = stinger_keys
			except: pass
		if stinger_keys:
			from windows.base_window import open_window
			self._spawn(lambda: open_window(('windows.playback_notifications', 'StingersNotification'), 'playback_notifications.xml', meta=self.meta), name='stingers_notification')

	def set_resume_point(self, listitem):
		if self.playback_percent > 0.0: listitem.setProperty('StartPercent', str(self.playback_percent))

	def _nextep_aio_en_fresh_start(self):
		try:
			sources = self.sources_object
			if not sources or not getattr(sources, '_nextep_aio_en_fresh_start', None):
				return False
			return sources._nextep_aio_en_fresh_start(getattr(self, 'playing_item', None))
		except:
			return False

	def _disable_kodi_url_resume(self, listitem, keep_start_percent=False):
		# Kodi stores resume by stream URL/filename; debrid links reuse the same name and can reopen near EOF.
		if not keep_start_percent or float(listitem.getProperty('StartPercent') or 0) <= 0:
			listitem.setProperty('StartPercent', '0')
		listitem.setProperty('StartOffset', '0')
		try:
			listitem.getVideoInfoTag(True).setResumePoint(0.0)
		except:
			pass

	def info_next_ep(self):
		self.nextep_info_gathered = True
		play_type = self._nextep_play_type()
		nextep_settings = st.auto_nextep_settings(play_type)
		pop_at, timing_source = self._pop_window_seconds(nextep_settings, self.total_time)
		credits_entry = self._subtitle_credits_entry_remaining(fetch=False) if nextep_settings.get('alert_timing') == 'subtitles' else None
		use_window = nextep_settings['alert_method'] == 0
		default_action = nextep_settings['default_action']
		# Play # Episodes: no Still Watching budget; headroom without that dialog.
		play_n_active = False
		try: play_n_remaining = int(self.num_episodes) if getattr(self, 'num_episodes', None) not in (None, '') else 0
		except: play_n_remaining = 0
		if play_n_remaining > 1:
			play_n_active = True
			use_window = False
			default_action = 'close'
		still_watching_due = False if play_n_active else self._still_watching_due(nextep_settings)
		self.start_prep = self._start_prep_seconds(nextep_settings, pop_at, play_type, include_still_watching=not play_n_active)
		pipeline = st.nextep_pipeline_headroom(play_type, nextep_settings['scraper_time'], still_watching_due)
		self.nextep_settings = {'use_window': use_window, 'window_time': pop_at, 'default_action': default_action, 'play_type': play_type,
			'alert_timing': nextep_settings.get('alert_timing'),
			'watching_check': 0 if play_n_active else nextep_settings['watching_check'],
			'pipeline_headroom': pipeline, 'credits_entry': credits_entry}
		if play_n_active:
			# Count for the *next* episode includes that episode; stop when it reaches 1.
			self.nextep_settings['num_episodes'] = str(play_n_remaining - 1)
			self.nextep_settings['play_n_episodes'] = True
		if nextep_settings.get('alert_timing') == 'introdb':
			outro_start = self._outro_credits_start(fetch=True)
			if outro_start is not None:
				self.nextep_settings['outro_start'] = outro_start
		credits_log = ' credits_entry=%ss' % credits_entry if credits_entry is not None else ''
		outro_start = self.nextep_settings.get('outro_start')
		outro_log = ' outro_start=%.1fs' % outro_start if outro_start is not None else ''
		play_n_log = ' play_n=%s' % play_n_remaining if play_n_remaining else ''
		self._log_nextep('Next episode timing: play_type=%s alert=%s source=%s pop_at=%ss pipeline=%ss start_prep=%ss total=%ss%s%s%s' % (
			play_type, nextep_settings.get('alert_timing'), timing_source, pop_at, pipeline, self.start_prep, round(float(self.total_time)), credits_log, outro_log, play_n_log))

	def _log_monitor_tick_error(self):
		# monitor() ticks once per second; a persistent fault would otherwise write a
		# traceback every second for the whole playback, so log each distinct one once
		try:
			trace = traceback.format_exc()
			seen = getattr(self, '_monitor_tick_errors', None)
			if seen is None:
				seen = self._monitor_tick_errors = set()
			if trace in seen: return
			seen.add(trace)
			ku.logger('Red Light', 'monitor() tick failed: %s' % trace)
		except Exception: pass

	def _log_chapter_timing(self, message):
		# monitor() calls final_chapter() once per second, so log each distinct
		# reason once per playback rather than on every tick
		if getattr(self, '_chapter_timing_logged', None) == message: return
		self._chapter_timing_logged = message
		ku.logger('Red Light', 'Chapter timing: %s' % message)

	def final_chapter(self, threshhold):
		# Player.Chapters is 'start1,end1,start2,end2,...' as percentages, built from
		# chapter start marks only, so the last token is the final chapter's start.
		# Empty means the item carries no chapter marks, not that the label is missing.
		raw = ''
		try:
			raw = ku.get_infolabel('Player.Chapters')
			if not raw:
				self._log_chapter_timing('no chapter marks on this item; using percentage-based timing')
				return None
			final_chapter = float(raw.split(',')[-1])
			if final_chapter >= threshhold: return final_chapter
			self._log_chapter_timing('final chapter starts at %.1f%%, below the %s%% threshold; using percentage-based timing' % (final_chapter, threshhold))
		except Exception:
			self._log_chapter_timing('could not parse Player.Chapters %r; using percentage-based timing' % raw)
		return None

	def _clear_subtitle_end_cache(self):
		self._subtitle_end_remaining_cached = '__unset__'
		self._subtitle_credits_entry_cached = '__unset__'

	def _subtitle_alert_fetch_pending(self):
		return getattr(self, '_subtitle_alert_fetch_started', False) and not getattr(self, '_subtitle_alert_fetch_done', False)

	def _maybe_start_introdb_alert_fetch(self):
		if getattr(self, '_introdb_alert_fetch_started', False): return
		if self.is_generic or self.media_type != 'episode': return
		if not (self.autoplay_nextep or self.autoscrape_nextep): return
		nextep_settings = st.auto_nextep_settings(self._nextep_play_type())
		if nextep_settings.get('alert_timing') != 'introdb': return
		self._introdb_alert_fetch_started = True
		season = self.season
		episode = self.episode
		tmdb_id, imdb_id = self.tmdb_id, self.imdb_id
		def _work():
			try:
				from apis.intro_skip_api import prefetch_credits_start
				duration = None
				try: duration = float(self.total_time) if self.total_time else None
				except: pass
				prefetch_credits_start(tmdb_id, imdb_id, season, episode, duration)
			except: pass
			finally:
				self._outro_credits_start_cached = '__unset__'
		self._spawn(_work, name='introdb_alert_fetch', daemon=True)

	def _maybe_start_subtitle_alert_fetch(self):
		if getattr(self, '_subtitle_alert_fetch_started', False): return
		if self.is_generic or not self.imdb_id: return
		if not st.subs_alert_fetch_enabled(self.media_type): return
		self._subtitle_alert_fetch_started = True
		season = self.season if self.media_type == 'episode' else None
		episode = self.episode if self.media_type == 'episode' else None
		year = getattr(self, 'year', None)
		playing_filename = getattr(self, 'playing_filename', None)
		playing_item = getattr(self, 'playing_item', None)
		def _work():
			try:
				from indexers.subtitles import fetch_subtitle_for_alert_timing
				fetch_subtitle_for_alert_timing(self.imdb_id, season, episode, year, playing_filename, playing_item)
			except: pass
			finally:
				self._subtitle_alert_fetch_done = True
				self._clear_subtitle_end_cache()
		self._spawn(_work, name='subtitle_alert_fetch', daemon=True)

	def _subtitle_end_remaining(self, fetch=False, for_alert=False):
		cached = getattr(self, '_subtitle_end_remaining_cached', '__unset__')
		cache_key = 'alert' if for_alert else 'scrape'
		cached_by_mode = cached if isinstance(cached, dict) else {}
		if cache_key in cached_by_mode and (cached_by_mode[cache_key] is not None or getattr(self, 'subs_searched', False)) and not self._subtitle_alert_fetch_pending():
			return cached_by_mode[cache_key]
		try:
			from indexers.subtitles import subtitle_seconds_remaining_before_end
			season = self.season if self.media_type == 'episode' else None
			episode = self.episode if self.media_type == 'episode' else None
			remaining = subtitle_seconds_remaining_before_end(float(self.total_time), self.imdb_id, season, episode, fetch=fetch,
				player=self, playing_filename=getattr(self, 'playing_filename', None), playing_item=getattr(self, 'playing_item', None),
				playback_started_at=getattr(self, '_playback_started_at', None),
				year=getattr(self, 'year', None), for_alert=for_alert)
		except:
			remaining = None
		if remaining is not None:
			cached_by_mode[cache_key] = remaining
			self._subtitle_end_remaining_cached = cached_by_mode
		elif getattr(self, 'subs_searched', False):
			cached_by_mode[cache_key] = None
			self._subtitle_end_remaining_cached = cached_by_mode
		return remaining

	def _alert_window_time(self, nextep_settings, chapter_threshold, total_time, still_watching_check=0):
		alert_timing = nextep_settings.get('alert_timing', 'off')
		window_percentage = nextep_settings['window_percentage']
		try: total_time = float(total_time)
		except:
			return window_percentage + still_watching_check, 'percentage'
		if alert_timing == 'chapters':
			final_chapter = self.final_chapter(chapter_threshold)
			if final_chapter:
				percentage = 100 - final_chapter
				return round((percentage / 100) * total_time) + still_watching_check, 'chapters'
		if alert_timing == 'subtitles':
			sub_remaining = self._subtitle_end_remaining(fetch=True, for_alert=True)
			credits_entry = self._subtitle_credits_entry_remaining(fetch=False, quiet=True)
			pop_at = self._resolve_subtitle_pop_at(sub_remaining, credits_entry)
			if pop_at is not None:
				return pop_at + still_watching_check, 'subtitles'
		if alert_timing == 'introdb':
			pop_at = self._outro_credits_pop_at(fetch=True)
			if pop_at is not None:
				return pop_at + still_watching_check, 'introdb'
		fallback = 'percentage_fallback' if alert_timing in ('chapters', 'subtitles', 'introdb') else 'percentage'
		pop_at = round((window_percentage / 100) * total_time) + still_watching_check
		if alert_timing == 'subtitles':
			pop_at = min(int(pop_at), st.NEXTEP_ALERT_MAX_REMAINING_SEC)
		return pop_at, fallback

	def _maybe_refresh_nextep_subtitle_timing(self):
		if not getattr(self, 'nextep_info_gathered', False) or not getattr(self, 'nextep_settings', None): return
		play_type = self._nextep_play_type()
		nextep_settings = st.auto_nextep_settings(play_type)
		if nextep_settings.get('alert_timing') != 'subtitles': return
		sub_alert = self._subtitle_end_remaining(fetch=False, for_alert=True)
		if sub_alert is None: return
		credits_entry = self._subtitle_credits_entry_remaining(fetch=False, quiet=True)
		pop_at = self._resolve_subtitle_pop_at(sub_alert, credits_entry)
		if pop_at is None: return
		start_prep = self._start_prep_seconds(nextep_settings, pop_at, play_type)
		pipeline = st.nextep_pipeline_headroom(play_type, nextep_settings['scraper_time'], self._still_watching_due(nextep_settings))
		if pop_at == self.nextep_settings.get('window_time') and start_prep == self.start_prep and credits_entry == self.nextep_settings.get('credits_entry'): return
		self.start_prep = start_prep
		self.nextep_settings['window_time'] = pop_at
		self.nextep_settings['pipeline_headroom'] = pipeline
		self.nextep_settings['credits_entry'] = credits_entry
		credits_log = ' credits_entry=%ss' % credits_entry if credits_entry is not None else ''
		self._log_nextep('Next episode timing refreshed (subtitles): pop_at=%ss start_prep=%ss%s' % (pop_at, start_prep, credits_log))

	def _maybe_refresh_nextep_chapter_timing(self):
		if not getattr(self, 'nextep_info_gathered', False) or not getattr(self, 'nextep_settings', None): return
		play_type = self._nextep_play_type()
		nextep_settings = st.auto_nextep_settings(play_type)
		if nextep_settings.get('alert_timing') != 'chapters': return
		if not self.final_chapter(90): return
		pop_at, _timing_source = self._alert_window_time(nextep_settings, 90, self.total_time, still_watching_check=0)
		start_prep = self._start_prep_seconds(nextep_settings, pop_at, play_type)
		pipeline = st.nextep_pipeline_headroom(play_type, nextep_settings['scraper_time'], self._still_watching_due(nextep_settings))
		if pop_at == self.nextep_settings.get('window_time') and start_prep == self.start_prep: return
		self.start_prep = start_prep
		self.nextep_settings['window_time'] = pop_at
		self.nextep_settings['pipeline_headroom'] = pipeline
		self._log_nextep('Next episode timing refreshed (chapters): pop_at=%ss start_prep=%ss' % (pop_at, start_prep))

	def _outro_credits_start(self, fetch=False):
		if getattr(self, 'is_generic', False) or self.media_type != 'episode':
			return None
		cache_attr = '_outro_credits_start_cached'
		if not fetch:
			cached = getattr(self, cache_attr, '__unset__')
			if cached != '__unset__':
				return cached
		try:
			from apis.intro_skip_api import resolve_credits_start_sec
			duration = float(self.total_time) if self.total_time else None
			start_sec = resolve_credits_start_sec(self.tmdb_id, self.imdb_id, self.season, self.episode, duration)
		except:
			start_sec = None
		setattr(self, cache_attr, start_sec)
		return start_sec

	def _outro_credits_pop_at(self, fetch=False):
		try:
			total_time = float(self.total_time)
		except:
			return None
		start_sec = self._outro_credits_start(fetch=fetch)
		if start_sec is None:
			return None
		pop_at = int(round(total_time - float(start_sec) + st.NEXTEP_INTRODB_BUFFER_SEC))
		return max(pop_at, st.NEXTEP_ALERT_MIN_REMAINING_SEC)

	def _maybe_refresh_nextep_introdb_timing(self):
		if not getattr(self, 'nextep_info_gathered', False) or not getattr(self, 'nextep_settings', None): return
		play_type = self._nextep_play_type()
		nextep_settings = st.auto_nextep_settings(play_type)
		if nextep_settings.get('alert_timing') != 'introdb': return
		pop_at = self._outro_credits_pop_at(fetch=False)
		if pop_at is None: return
		start_prep = self._start_prep_seconds(nextep_settings, pop_at, play_type)
		pipeline = st.nextep_pipeline_headroom(play_type, nextep_settings['scraper_time'], self._still_watching_due(nextep_settings))
		outro_start = getattr(self, '_outro_credits_start_cached', None)
		if pop_at == self.nextep_settings.get('window_time') and start_prep == self.start_prep and outro_start == self.nextep_settings.get('outro_start'): return
		self.start_prep = start_prep
		self.nextep_settings['window_time'] = pop_at
		self.nextep_settings['pipeline_headroom'] = pipeline
		self.nextep_settings['outro_start'] = outro_start
		outro_log = ' outro_start=%.1fs' % outro_start if outro_start is not None else ''
		self._log_nextep('Next episode timing refreshed (introdb): pop_at=%ss start_prep=%ss%s' % (pop_at, start_prep, outro_log))

	def _stinger_early_percentage(self, trigger_pct):
		try:
			total = float(self.total_time)
			if total > 0:
				trigger_pct = round(trigger_pct - (_STINGER_EARLY_OFFSET_SEC / total * 100), 1)
				return max(1.0, trigger_pct)
		except: pass
		return trigger_pct

	def _stinger_trigger_point(self, alert_timing, fallback_percentage):
		if alert_timing == 'chapters':
			trigger_pct = self.final_chapter(75) or fallback_percentage
		elif alert_timing == 'subtitles':
			trigger_pct = fallback_percentage
			try:
				sub_remaining = self._subtitle_end_remaining(fetch=True, for_alert=True)
				if sub_remaining is not None and self.total_time:
					trigger_pct = round(100 - (float(sub_remaining) / float(self.total_time) * 100), 1)
			except: pass
		else:
			trigger_pct = fallback_percentage
		return self._stinger_early_percentage(trigger_pct)

	def kill_dialog(self):
		try:
			self.sources_object._kill_progress_dialog()
		except:
			if not getattr(self.sources_object, '_resolve_user_cancelled', False):
				ku.close_all_dialog()

	def set_constants(self, url, obj):
		self.url = url
		self.sources_object = obj
		self.is_generic = self.sources_object == 'video'
		self.kodi_monitor = ku.kodi_monitor()
		self.playback_successful = None
		self.cancel_all_playback = False
		if not self.is_generic:
			self.meta = self.sources_object.meta
			self.meta_get, self.playback_percent = self.meta.get, self.sources_object.playback_percent or 0.0
			self.playing_filename = self.sources_object.playing_filename
			self.media_marked, self.nextep_info_gathered, self.movie_stingers_run = False, False, False
			self.current_point = 0
			self.subs_searched = False
			self._subtitle_end_remaining_cached = '__unset__'
			self._subtitle_alert_fetch_started = False
			self._subtitle_alert_fetch_done = False
			self._playback_started_at = time.time()
			self._nextep_prep_attempted = False
			ku.clear_property(PROP_NEXTEP_PENDING)
			ku.clear_property(PROP_NEXTEP_PREP_SCHEDULED)
			ku.clear_property(PROP_NEXTEP_PREP_DECLINED)
			ku.clear_property(PROP_NEXTEP_NATURAL_END)
			ku.clear_property(PROP_AUTOSCRAPE_NEXTEP_READY)
			ku.clear_property(PROP_NEXTEP_AUTOPLAY_CANCELLED)
			ku.clear_property(PROP_RANDOM_CONTINUAL_SKIP_ATTEMPTS)
			ku.clear_property(ku.PROP_AUTOSCRAPE_TOAST_SHOWN)
			self._autoscrape_ready_notified = False
			self._nextep_alert_pending_logged = False
			self._nextep_close_wait = False
			self._nextep_stash_play_scheduled = False
			self.playing_item = self.sources_object.playing_item
			self._intro_skip_active = False
			self._intro_skip_done = False
			self._intro_skip_segment = None
			self._intro_skip_no_timing_logged = False
			self._intro_skip_last_curr = None
			self._intro_skip_settle_ready = False
			self._outro_credits_start_cached = '__unset__'
			self._chapter_timing_logged = None
			self._monitor_tick_errors = None

	def _start_intro_skip_fetch(self):
		play_type = getattr(self.sources_object, 'play_type', '')
		if not st.autoplay_skip_intro_enabled(play_type) or self.media_type != 'episode':
			return
		self._intro_skip_active = True
		self._intro_skip_done = False
		self._intro_skip_prompt_answered = False
		self._intro_skip_approved = st.autoplay_skip_intro_auto(play_type)
		self._intro_skip_fetch_done = False
		self._intro_skip_no_timing_logged = False
		try:
			from apis.intro_skip_api import peek_intro_segment_cache
			cached = peek_intro_segment_cache(self.tmdb_id, self.imdb_id, self.season, self.episode)
			if cached != '__miss__':
				self._intro_skip_fetch_done = True
				if cached:
					self._intro_skip_segment = cached
				return
		except: pass
		def _work():
			try:
				from apis.intro_skip_api import resolve_intro_segment
				total = getattr(self, 'total_time', None)
				duration = None
				try:
					if total not in (None, '', 0, 0.0): duration = float(total)
				except: pass
				segment = resolve_intro_segment(self.tmdb_id, self.imdb_id, self.season, self.episode, duration)
				if segment and not getattr(self, '_intro_skip_segment', None):
					self._intro_skip_segment = segment
			except: pass
			finally:
				self._intro_skip_fetch_done = True
		self._spawn(_work, name='intro_skip_fetch', daemon=True)

	def _try_intro_skip_chapters(self):
		if getattr(self, '_intro_skip_segment', None):
			return
		if not getattr(self, '_intro_skip_fetch_done', False):
			return
		try:
			total = float(self.total_time)
			if total < 60:
				return
			raw = ku.get_infolabel('Player.Chapters')
			if not raw:
				return
			marks = [float(x) for x in raw.split(',') if x.strip()]
			if len(marks) < 2:
				return
			start_pct, end_pct = marks[0], marks[1]
			if start_pct > 5 or end_pct > 30 or end_pct <= start_pct:
				return
			start_sec = total * start_pct / 100.0
			end_sec = total * end_pct / 100.0
			if start_sec < _INTRO_CHAPTER_MIN_START_SEC:
				return
			if end_sec - start_sec < _INTRO_CHAPTER_MIN_SEGMENT_SEC or end_sec < _INTRO_CHAPTER_MIN_END_SEC:
				return
			self._intro_skip_segment = {'start_sec': start_sec, 'end_sec': end_sec, 'source': 'chapters'}
		except: pass

	def _maybe_log_intro_skip_no_timing(self):
		if getattr(self, '_intro_skip_no_timing_logged', False):
			return
		if not getattr(self, '_intro_skip_fetch_done', False):
			return
		if getattr(self, '_intro_skip_segment', None):
			return
		self._try_intro_skip_chapters()
		if getattr(self, '_intro_skip_segment', None):
			return
		self._intro_skip_no_timing_logged = True
		self._intro_skip_done = True
		self._log_intro_skip('Intro skip: no timing (api miss, chapters rejected)')

	def _intro_resume_sec(self):
		if self.playback_percent and float(self.playback_percent) > 0:
			try: return float(self.total_time) * float(self.playback_percent) / 100.0
			except: pass
		return None

	def _intro_effective_playhead(self):
		try: curr = float(self.curr_time)
		except: curr = 0.0
		resume_sec = self._intro_resume_sec()
		if resume_sec is not None: return max(curr, resume_sec)
		return curr

	def _intro_skip_position_settled(self):
		if getattr(self, '_intro_skip_settle_ready', False): return True
		started = getattr(self, '_playback_started_at', None)
		if not started: return True
		elapsed = time.time() - started
		try: curr = float(self.curr_time)
		except: return False
		last = getattr(self, '_intro_skip_last_curr', None)
		if last is not None and abs(curr - last) >= _INTRO_SKIP_SETTLE_JUMP_SEC:
			self._intro_skip_last_curr = curr
			return False
		resume_sec = self._intro_resume_sec()
		if resume_sec is not None and resume_sec > _INTRO_SKIP_PROMPT_EARLY_SEC:
			self._intro_skip_settle_ready = True
			return True
		if elapsed < _INTRO_SKIP_SETTLE_SEC:
			self._intro_skip_last_curr = curr
			return False
		if last is not None and abs(curr - last) <= 3:
			self._intro_skip_settle_ready = True
			return True
		if elapsed >= _INTRO_SKIP_SETTLE_MAX_WAIT_SEC:
			self._intro_skip_settle_ready = True
			return True
		self._intro_skip_last_curr = curr
		return False

	def _intro_skip_past_segment(self, segment):
		try:
			end_sec = float(segment['end_sec'])
			curr = self._intro_effective_playhead()
			if getattr(self, '_intro_skip_approved', False) and curr < end_sec + _INTRO_SKIP_POST_END_GRACE_SEC:
				return False
			if curr >= end_sec:
				return True
		except: pass
		return False

	def _execute_intro_skip_seek(self, start_sec, end_sec, source):
		if not self._player_is_active():
			self._log_intro_skip('Intro skip failed: player inactive')
			return False
		if not self.seek(end_sec, False):
			self._log_intro_skip('Intro skip failed: seek rejected')
			return False
		try:
			ku.sleep(400)
			actual = float(self.getTime())
			if abs(actual - end_sec) > 8:
				if not self.seek(end_sec, False):
					self._log_intro_skip('Intro skip failed: seek did not stick (at %.1fs, wanted %.1fs)' % (actual, end_sec))
					return False
				ku.sleep(400)
				actual = float(self.getTime())
				if abs(actual - end_sec) > 8:
					self._log_intro_skip('Intro skip failed: seek did not stick (at %.1fs, wanted %.1fs)' % (actual, end_sec))
					return False
		except Exception as exc:
			self._log_intro_skip('Intro skip failed: seek verify (%s)' % exc)
			return False
		self._log_intro_skip('Intro skip (%s): %.1fs -> %.1fs' % (source, start_sec, end_sec))
		return True

	def _prompt_intro_skip(self):
		if not self._player_is_active():
			return False
		try:
			from windows.base_window import open_window
			return open_window(('windows.playback_notifications', 'IntroSkipPrompt'), 'playback_notifications.xml',
				meta=self.meta, countdown_sec=_INTRO_SKIP_PROMPT_COUNTDOWN_SEC)
		except:
			return False

	def _maybe_apply_intro_skip(self):
		if not getattr(self, '_intro_skip_active', False) or getattr(self, '_intro_skip_done', False):
			return
		if not self._player_is_active():
			return
		self._try_intro_skip_chapters()
		segment = getattr(self, '_intro_skip_segment', None)
		if not segment:
			self._maybe_log_intro_skip_no_timing()
			return
		if self._intro_skip_past_segment(segment):
			if getattr(self, '_intro_skip_approved', False):
				self._log_intro_skip('Intro skip missed: past grace window')
			self._intro_skip_done = True
			return
		try:
			start_sec = float(segment['start_sec'])
			end_sec = float(segment['end_sec'])
			curr = float(self.curr_time)
		except:
			return
		if not getattr(self, '_intro_skip_prompt_answered', False) and st.skip_intro_needs_prompt(getattr(self.sources_object, 'play_type', '')):
			if not self._intro_skip_position_settled():
				return
			effective_curr = self._intro_effective_playhead()
			should_prompt = (start_sec <= _INTRO_SKIP_EARLY_START_SEC and effective_curr <= _INTRO_SKIP_PROMPT_EARLY_SEC) or (effective_curr >= start_sec and effective_curr < end_sec)
			if should_prompt:
				choice = self._prompt_intro_skip()
				self._intro_skip_prompt_answered = True
				if choice is None:
					self._intro_skip_done = True
					self._log_intro_skip('Intro skip: timed out')
					return
				if not choice:
					self._intro_skip_done = True
					self._log_intro_skip('Intro skip: declined')
					return
				self._intro_skip_approved = True
				try:
					curr = float(self.curr_time)
				except:
					return
		if not getattr(self, '_intro_skip_approved', False):
			return
		if self._intro_skip_past_segment(segment):
			self._log_intro_skip('Intro skip missed: past grace window')
			self._intro_skip_done = True
			return
		if curr < start_sec:
			return
		if curr >= end_sec:
			self._intro_skip_done = True
			self._log_intro_skip('Intro skip: already past intro (%.1fs >= %.1fs)' % (curr, end_sec))
			return
		try:
			if self._execute_intro_skip_seek(start_sec, end_sec, segment.get('source', '?')):
				self._intro_skip_done = True
		except Exception as exc:
			self._log_intro_skip('Intro skip failed: %s' % exc)
			self._intro_skip_done = True

	def run_subtitles(self):
		self.subs_searched = True
		self._clear_subtitle_end_cache()
		if not st.auto_enable_subs(): return
		if not self.imdb_id: return
		try:
			from indexers.subtitles import subtitle_notify_poster
			poster = subtitle_notify_poster(self.meta, self.media_type)
			season = self.season if self.media_type == 'episode' else None
			episode = self.episode if self.media_type == 'episode' else None
			year = getattr(self, 'year', None)
			playing_filename = getattr(self, 'playing_filename', None)
			playing_item = getattr(self, 'playing_item', None)
			if st.submaker_enabled():
				from indexers.subtitles import Subtitles
				self._spawn(Subtitles().run, args=(self.imdb_id, season, episode, poster, playing_filename, playing_item, self), name='subtitles')
			elif st.opensubs_enabled():
				from indexers.subtitles import OpenSubtitlesSubs
				self._spawn(OpenSubtitlesSubs().run, args=(self.imdb_id, season, episode, poster, year, playing_filename, playing_item, self), name='opensubtitles')
		except: pass

	def set_playback_properties(self):
		try:
			trakt_ids = {'tmdb': self.tmdb_id, 'imdb': self.imdb_id, 'slug': make_trakt_slug(self.title)}
			if self.media_type == 'episode': trakt_ids['tvdb'] = self.tvdb_id
			ku.set_property('script.trakt.ids', json.dumps(trakt_ids))
			if self.playing_filename or getattr(self, 'playing_item', None):
				try:
					from indexers.subtitles import _best_play_filename
					season = self.season if self.media_type == 'episode' else None
					episode = self.episode if self.media_type == 'episode' else None
					best = _best_play_filename(self.playing_filename, getattr(self, 'playing_item', None), season, episode)
					ku.set_property('subs.player_filename', best or self.playing_filename)
				except:
					if self.playing_filename: ku.set_property('subs.player_filename', self.playing_filename)
			elif self.playing_filename:
				ku.set_property('subs.player_filename', self.playing_filename)
			# Deliberately separate from subs.player_filename above: that property runs through
			# _best_play_filename()'s subtitle-matching heuristic, which scores candidates by
			# season/episode text match and can pick a different string out of playing_item than
			# the literal source release name -- fine for subtitle search, wrong for anything that
			# needs to know what file is actually playing (see sources.py's next-episode
			# duplicate-file check).
			if self.playing_filename:
				ku.set_property('redlight.now_playing_release', self.playing_filename)
			# Survives clear_playback_properties(), so the service can recognise this play if Kodi
			# resumes it on wake with no RedLightPlayer behind it (#143).
			from modules.wake_resume import write_adopt_stash, write_last_play_record
			write_last_play_record(self)
			write_adopt_stash(self)
		except: pass

	def safe_stop(self):
		try:
			opening = ku.get_property(PROP_PLAY_OPENING) == 'true'
			if opening and not self.isPlayingVideo() and not ku.get_visibility('Window.IsActive(fullscreenvideo)'):
				ku.execute_builtin('PlayerControl(Stop)', block=False)
				return
			if self.isPlayingVideo() or ku.get_visibility('Window.IsActive(fullscreenvideo)'):
				if self.isPlaying():
					self.stop()
				ku.sleep(150)
			elif self.isPlaying():
				ku.execute_builtin('PlayerControl(Stop)', block=False)
				ku.sleep(100)
		except:
			pass
		finally:
			ku.clear_property(PROP_PLAY_OPENING)

	def clear_playback_properties(self, clear_navigation=True):
		if clear_navigation:
			ku.clear_property('redlight.window_stack')
		ku.clear_property('script.trakt.ids')
		ku.clear_property('subs.player_filename')
		ku.clear_property('redlight.now_playing_release')
		try:
			from indexers.subtitles import clear_active_subtitle_path
			clear_active_subtitle_path()
		except: pass

	def run_error(self, message=None):
		ku.clear_property(PROP_PLAY_OPENING)
		try:
			if not self.is_generic:
				self.sources_object.playback_successful = False
		except:
			pass
		self.clear_playback_properties(clear_navigation=not self.is_generic)
		if self.is_generic and ku.get_property('redlight.browse_playback') == 'true':
			return ku.notification('Playback Failed', 4000, settle_ms=400)
		# play_file walks the resolve queue and calls playback_failed_action after the last attempt.
		if not self.is_generic and getattr(self, 'sources_object', None):
			return
		text = message or 'This link could not be played. It may be expired, removed, or unsupported on this device.'
		ku.hide_busy_dialog()
		ku.sleep(400)
		try:
			return ku.kodi_dialog().ok('Playback failed', text)
		except Exception:
			try:
				return ku.ok_dialog(heading='Playback failed', text=text)
			except Exception:
				return ku.notification('Playback Failed', 4000, settle_ms=400)
