# -*- coding: utf-8 -*-
import calendar
import sys
import time
from caches.widget_cache import widget_cache
from modules import nextep_list_cache
from modules.episode_rows import render_episode_row
from modules import kodi_utils, settings, watched_status as ws
from modules.metadata import (tvshow_meta, episodes_meta, all_episodes_meta, resolve_assigned_episode_group, group_episode_data,
								group_traversal_reachable, group_season_bucket_episodes)
from modules.utils import jsondate_to_datetime, adjust_premiered_date, make_day, get_datetime, get_current_timestamp, title_key, date_difference, TaskPool, datetime_workaround
from datetime import timedelta
# logger = kodi_utils.logger

def _group_display_numbers(tmdb_id, season, episode, episode_id, group_cache):
	"""Season/episode as the show's assigned TMDb episode group numbers them, for DISPLAY only.

	Playback, watched status and scrape params stay on raw TMDb numbering -- the same split
	build_episode_list() already uses, since the watched table and scrapers are raw-keyed.
	Returns None when no group applies, so callers fall back to the raw numbers unchanged.

	Unlike build_episode_list(), which renders one show, each widget row is a different show,
	so group details are memoised per tmdb_id here rather than resolved once per list.
	"""
	if not tmdb_id or season == 0: return None
	try:
		if tmdb_id not in group_cache:
			try: group_cache[tmdb_id] = resolve_assigned_episode_group(tmdb_id)
			except Exception: group_cache[tmdb_id] = None
		group_details = group_cache[tmdb_id]
		if not group_details: return None
		return group_episode_data(group_details, episode_id, season, episode)
	except Exception:
		return None

def _group_traversal_reachable(group_details, meta):
	"""Whether every bucket corresponds to a season row the user can actually open.

	Thin wrapper so the season list (seasons.py, for its episode totals) and the episode list
	agree on when traversal is in play -- they must, or the counters describe a different list
	than the one rendered.
	"""
	return group_traversal_reachable(group_details, (meta or {}).get('season_data'))

def _group_season_episodes(group_details, season, meta):
	"""Raw episode dicts for one group season, in the group's own order.

	A bucket lists raw (season_number, episode_number) pairs that may span more than one raw
	season -- that is the point: a group can move an episode between regular seasons (Seinfeld raw
	S03E10 "The Stranded" belongs to group season 2). Episodes the group places in NO bucket are
	appended from this season's raw list, since groups do not necessarily cover every episode
	(Seinfeld's DVD-order group omits 4 specials outright) and without that sweep those would
	disappear from the UI entirely.

	Thin wrapper over metadata.group_season_bucket_episodes() -- shared with seasons.py's
	count_aired_group_season() (#77) so the rendered list and the aired-episode count agree on
	exactly which episodes a group season contains.

	Returns (items, raw_seasons), or None to fall back to the raw season list.
	"""
	return group_season_bucket_episodes(group_details, season, meta)

def _calendar_episode_date(service_first_aired, tmdb_premiered, adjust_hours):
	"""Use Trakt/MDBList air date for calendar label + sort (not TMDb premiered).

	Do not invent TMDb 20:00 / apply date_offset() here — that can push service calendar
	days one day ahead. Date-only events keep their calendar day; ISO timestamps
	use the user UTC (+/-) setting only.
	"""
	if service_first_aired:
		fa = str(service_first_aired)
		try:
			if 'T' in fa:
				dt = datetime_workaround(fa, '%Y-%m-%dT%H:%M:%S.%fZ')
				if dt is None:
					dt = datetime_workaround(fa.split('.')[0].rstrip('Z'), '%Y-%m-%dT%H:%M:%S')
				if dt is not None:
					adjusted = dt + timedelta(hours=settings.datetime_utc_offset())
					return adjusted.date(), adjusted.strftime('%Y-%m-%d')
			day = fa.split('T')[0][:10]
			d = jsondate_to_datetime(day, '%Y-%m-%d', remove_time=True)
			if d is not None:
				return d, day
		except Exception:
			pass
	return adjust_premiered_date(tmdb_premiered, adjust_hours)

def _nextep_indicator_watchlist(indicators=None):
	"""Never-started shows from a Watched Status Provider service watchlist (empty for Red Light)."""
	if indicators is None: indicators = settings.watched_indicators()
	try:
		if indicators == 1:
			from apis.trakt_api import trakt_watchlist
			data = trakt_watchlist('tvshow', '') or []
			return [{'media_ids': i['media_ids'], 'title': i.get('title', '')} for i in data if i.get('media_ids')]
		if indicators == 2:
			from apis.simkl_api import simkl_plantowatch
			data = (simkl_plantowatch('shows') or []) + (simkl_plantowatch('anime') or [])
			return [{'media_ids': i['media_ids'], 'title': i.get('title', '')} for i in data if i.get('media_ids')]
		if indicators == 3:
			from apis.mdblist_api import mdblist_watchlist_media_ids
			return mdblist_watchlist_media_ids('shows')
		if indicators == 4:
			from apis.punchplay_api import punchplay_watchlist
			data = (punchplay_watchlist('shows') or []) + (punchplay_watchlist('anime') or [])
			return [{'media_ids': i['media_ids'], 'title': i.get('title', '')} for i in data if i.get('media_ids')]
	except: pass
	return []

def build_episode_list(params):
	def _process():
		for item in episodes_data:
			try:
				cm = []
				cm_append = cm.append
				listitem = make_listitem()
				set_properties = listitem.setProperties
				item_get = item.get
				season, episode, ep_name = item_get('season'), item_get('episode'), item_get('title')
				season_special = season == 0
				episode_date, premiered = adjust_premiered_date(item_get('premiered'), adjust_hours)
				episode_type = item_get('episode_type') or ''
				episode_id = item_get('episode_id') or None
				if season_special: playcount, progress = 0, None
				else:
					playcount = ws.get_watched_status_episode(watched_info, (season, episode))
					if playcount and hide_watched: continue
					if total_seasons: progress = ws.get_progress_status_all_episode(bookmarks, season, episode)
					else: progress = ws.get_progress_status_episode(bookmarks, episode)
				if no_spoilers and not playcount: thumb, plot = show_landscape or show_fanart, tvshow_plot or '* Hidden to Prevent Spoilers *'
				else: thumb, plot = item_get('thumb', None) or show_landscape or show_fanart, item_get('plot') or tvshow_plot
				try: year = premiered.split('-')[0]
				except: year = show_year or '2050'
				duration = item_get('duration')
				if not duration:
					duration = show_duration
					item['duration'] = duration
				if group_details and not season_special:
					mapped = group_episode_data(group_details, episode_id, season, episode)
				else: mapped = None
				# The group relocated this raw episode OUT of its regular season INTO Specials -- TMDb's own
				# signal it isn't a numbered episode here anymore (e.g. the folded-away half of a combined-file
				# release). Hide it, matching watched_status._group_filtered_episode_numbers(). mapped is None
				# when the raw episode has no group entry at all (leave alone, fall back to raw numbering), and
				# the guard above already skips Specials' own listing, so a special can't filter itself out.
				# Only needed on the raw-season path. Under group-native traversal the bucket itself
				# defines membership, and filtering here would drop the episodes the group moved
				# INTO Specials from the Specials listing too -- making them unreachable entirely.
				if not group_native and mapped and mapped.get('season') == 0: continue
				display_season, display_episode = (mapped['season'], mapped['episode']) if mapped else (season, episode)
				str_episode_zfill2 = str(display_episode).zfill(2)
				seas_ep = '%sx%s. ' % (display_season, str_episode_zfill2)
				if not episode_date or current_date < episode_date:
					display, unaired = '[COLOR red][I]%s%s[/I][/COLOR]' % (seas_ep, ep_name), True
					item['title'] = display
				else: display, unaired = '%s%s' % (seas_ep, ep_name), False
				extras_params = build_url({'mode': 'extras_menu_choice', 'tmdb_id': tmdb_id, 'media_type': 'episode', 'is_external': is_external})
				options_params = build_url({'mode': 'options_menu_choice', 'content': 'episode', 'tmdb_id': tmdb_id, 'poster': show_poster, 'is_external': is_external,
											'season': season, 'episode': episode, 'episode_id': episode_id})
				playback_options_params = build_url({'mode': 'playback_choice', 'media_type': 'episode', 'meta': tmdb_id, 'season': season, 'playcount': playcount,
												'episode': episode, 'episode_id': episode_id})
				play_params = build_url({'mode': play_mode, 'media_type': 'episode', 'tmdb_id': tmdb_id, 'season': season, 'episode': episode, 'playcount': playcount,
										'episode_id': episode_id, playback_key: playback_key})
				cm_append(['extras', ('[B]Extras[/B]', 'RunPlugin(%s)' % extras_params)])
				cm_append(['options', ('[B]Options[/B]', 'RunPlugin(%s)' % options_params)])
				cm_append(['playback_options', ('[B]Play Options[/B]', 'RunPlugin(%s)' % playback_options_params)])
				settings.append_source_shortcut_context_menus(cm_append, build_url, cm_sort_order, 'episode', tmdb_id, season, episode, playcount)
				settings.append_external_scraper_settings_cm(cm_append, build_url)
				if not unaired and not season_special:
					if playcount:
						cm_append(['mark_watched', ('[B]Mark Unwatched[/B]', 'RunPlugin(%s)' % build_url({'mode': 'watched_status.mark_episode', 'action': 'mark_as_unwatched',
													'tmdb_id': tmdb_id, 'tvdb_id': tvdb_id, 'season': season, 'episode': episode,  'title': title}))])
						cm_append(['mark_watched', ('[B]Rewatch From Here[/B]', 'RunPlugin(%s)' % build_url({'mode': 'watched_status.rewatch_cursor', 'action': 'set',
													'tmdb_id': tmdb_id, 'season': season, 'episode': episode}))])
					else: cm_append(['mark_watched', ('[B]Mark Watched[/B]', 'RunPlugin(%s)' % build_url({'mode': 'watched_status.mark_episode', 'action': 'mark_as_watched',
													'tmdb_id': tmdb_id, 'tvdb_id': tvdb_id, 'season': season, 'episode': episode,  'title': title}))])
					if progress: cm_append(['mark_watched', ('[B]Clear Progress[/B]', 'RunPlugin(%s)' % \
								build_url({'mode': 'watched_status.erase_bookmark', 'media_type': 'episode', 'tmdb_id': tmdb_id,
								'season': season, 'episode': episode, 'refresh': 'true'}))])
				if is_external:
					cm.extend([['refresh', ('[B]Refresh Widgets[/B]', 'RunPlugin(%s)' % build_url({'mode': 'refresh_widgets'}))],
							['reload', ('[B]Reload Widgets[/B]', 'RunPlugin(%s)' % build_url({'mode': 'kodi_refresh'}))]])
				if custom_cm_menu:
					try: cm = sorted([i for i in cm if i[0] in cm_sort_order], key=lambda k: cm_sort_order[k[0]])
					except: pass
				cm = [i[1] for i in cm]
				studios = list(studio) if isinstance(studio, tuple) else (studio or [])
				info_tag = listitem.getVideoInfoTag(True)
				info_tag.setMediaType('episode'), info_tag.setTitle(ep_name), info_tag.setOriginalTitle(orig_title), info_tag.setTvShowTitle(title), info_tag.setGenres(genre)
				info_tag.setPlaycount(playcount), info_tag.setSeason(display_season), info_tag.setEpisode(display_episode), info_tag.setPlot(plot)
				info_tag.setDuration(duration), info_tag.setIMDBNumber(imdb_id), info_tag.setUniqueIDs({'imdb': imdb_id, 'tmdb': str(tmdb_id), 'tvdb': str(tvdb_id)})
				info_tag.setFirstAired(premiered), info_tag.setTvShowStatus(show_status)
				info_tag.setCountries(country), info_tag.setTrailer(trailer), info_tag.setDirectors(item_get('director'))
				info_tag.setYear(int(year)), info_tag.setRating(item_get('rating')), info_tag.setVotes(item_get('votes')), info_tag.setMpaa(mpaa)
				info_tag.setStudios(studios), info_tag.setWriters(item_get('writer'))
				full_cast = cast + (item_get('guest_stars') or [])
				info_tag.setCast([kodi_actor(name=item['name'], role=item['role'], thumbnail=item['thumbnail']) for item in full_cast])
				if progress and not unaired:
					# Time only — total would make Kodi/skins show a resume dialog we cannot honour.
					resume_secs = ws.get_resume_seconds(progress, duration)
					info_tag.setResumePoint(resume_secs)
					set_properties({'WatchedProgress': progress})
				listitem.setLabel(display)
				listitem.addContextMenuItems(cm)
				listitem.setArt({'poster': show_poster, 'fanart': show_fanart, 'thumb': thumb, 'icon':thumb, 'clearlogo': show_clearlogo, 'landscape': show_landscape,
								'season.poster': season_poster, 'tvshow.poster': show_poster, 'tvshow.clearlogo': show_clearlogo})
				set_properties({
					'episode_type': episode_type, 'redlight.extras_params': extras_params, 'redlight.options_params': options_params,
					'redlight.playback_options_params': playback_options_params
					})
				yield (play_params, listitem, False)
			except: pass
	kodi_actor, make_listitem, build_url = kodi_utils.kodi_actor(), kodi_utils.make_listitem, kodi_utils.build_url
	poster_empty, fanart_empty = kodi_utils.get_icon('box_office'), kodi_utils.addon_fanart()
	handle, is_external = int(sys.argv[1]), kodi_utils.external()
	no_spoilers = settings.avoid_episode_spoilers()
	item_list = []
	append = item_list.append
	watched_indicators, adjust_hours = settings.watched_indicators(), settings.date_offset()
	current_date, hide_watched = get_datetime(), is_external and settings.widget_hide_watched()
	cm_sort_order = settings.cm_sort_order()
	custom_cm_menu = cm_sort_order != settings.cm_default_order()
	rpdb_info = settings.rpdb_info('tvshow')
	rpdb_api_key, rpdb_format = rpdb_info['rpdb_api_key'], rpdb_info['rpdb_format']
	playback_key = settings.playback_key()
	play_mode = 'playback.%s' % playback_key
	meta = tvshow_meta('tmdb_id', params.get('tmdb_id'), settings.tmdb_api_key(), settings.mpaa_region(), current_date)
	meta_get = meta.get
	tmdb_id, tvdb_id, imdb_id, tvshow_plot, orig_title = meta_get('tmdb_id'), meta_get('tvdb_id'), meta_get('imdb_id'), meta_get('plot'), meta_get('original_title')
	title, show_year, rootname, show_duration, show_status = meta_get('title'), meta_get('year') or '2050', meta_get('rootname'), meta_get('duration'), meta_get('status')
	mpaa, trailer, genre, studio, country = meta_get('mpaa'), str(meta_get('trailer')), meta_get('genre'), meta_get('studio'), meta_get('country')
	cast = meta_get('short_cast', []) or meta_get('cast', []) or []
	season = params['season']
	try: group_details = resolve_assigned_episode_group(tmdb_id)
	except: group_details = None
	group_native = False
	if rpdb_api_key:
		try: show_poster = meta_get('rpdb_poster') % rpdb_api_key + rpdb_format
		except: show_poster = meta_get('poster') or poster_empty
	else: show_poster = meta_get('poster') or poster_empty
	show_fanart = meta_get('fanart') or fanart_empty
	show_clearlogo = meta_get('clearlogo') or ''
	show_landscape = meta_get('landscape') or ''
	watched_db = ws.get_database(watched_indicators)
	watched_info = ws.watched_info_episode(tmdb_id, watched_db)
	if season == 'all':
		total_seasons = meta_get('total_seasons')
		episodes_data = sorted(all_episodes_meta(meta, settings.show_specials()), key=lambda x: (x['season'], x['episode']))
		bookmarks = ws.get_bookmarks_all_episode(tmdb_id, total_seasons, watched_db)
		season_poster = show_poster
		category_name = 'Season %s' % season if total_seasons == 1 else 'Seasons 1-%s' % total_seasons
	else:
		total_seasons = None
		episodes_data = bookmarks = None
		# Group-native traversal: build this season from the assigned group's own bucket, so an
		# episode the group moved here from another raw season appears here, and one it moved away
		# does not. Falls back to the raw season list whenever the group has no usable bucket.
		if group_details and _group_traversal_reachable(group_details, meta):
			resolved = _group_season_episodes(group_details, season, meta)
			if resolved:
				episodes_data, raw_seasons = resolved
				# A bucket can span raw seasons, so episode numbers alone are ambiguous; key
				# bookmarks by raw season and let _process() use the (season, episode) lookup.
				bookmarks = {}
				for raw_season in raw_seasons:
					try: bookmarks[raw_season] = ws.get_bookmarks_episode(tmdb_id, raw_season, watched_db)
					except Exception: bookmarks[raw_season] = {}
				total_seasons = True
				group_native = True
		if episodes_data is None:
			episodes_data = episodes_meta(season, meta)
			bookmarks = ws.get_bookmarks_episode(tmdb_id, season, watched_db)
		try:
			season_data = meta_get('season_data')
			poster_path = next((i['poster_path'] for i in season_data if i['season_number'] == int(season)), None)
			season_poster = 'https://image.tmdb.org/t/p/w780%s' % poster_path if poster_path is not None else show_poster
		except: season_poster = show_poster
		category_name = 'Season %s' % season
	kodi_utils.add_items(handle, list(_process()))
	kodi_utils.set_sort_method(handle, 'episodes', labelMask='%L')
	kodi_utils.set_content(handle, 'episodes')
	kodi_utils.set_category(handle, category_name)
	kodi_utils.end_directory(handle, cacheToDisc=False if is_external else True)
	kodi_utils.set_view_mode('view.episodes', 'episodes', is_external)

def build_single_episode(list_type, params={}):
	category_override = None
	def _get_category_name():
		if category_override: return category_override
		try:
			cat_name = {'episode.progress': 'In Progress Episodes',
						'episode.recently_watched': 'Recently Watched Episodes',
						'episode.next_trakt': 'Next Episodes', 'episode.next_redlight': 'Next Episodes',
						'episode.next_simkl': 'Next Episodes', 'episode.next_mdblist': 'Next Episodes', 'episode.next_punchplay': 'Next Episodes',
						'episode.trakt': {'true': 'Recently Aired Episodes', None: 'Trakt Calendar'},
						'episode.mdblist': 'MDBList Calendar', 'episode.mdblist_calendar': 'MDBList Calendar',
						'episode.mdblist_next': 'MDBList Next Up',
						'episode.punchplay': 'PunchPlay Calendar', 'episode.punchplay_calendar': 'PunchPlay Calendar',
						'episode.simkl': 'Simkl Calendar', 'episode.simkl_calendar': 'Simkl Calendar'}[list_type]
			if isinstance(cat_name, dict): cat_name = cat_name[params.get('recently_aired')]
		except: cat_name = 'Episodes'
		return cat_name
	def _process(_position, ep_data):
		try:
			ep_data_get = ep_data.get
			meta = tvshow_meta('trakt_dict', ep_data_get('media_ids'), api_key, mpaa_region_value, current_date, current_time, is_anime_list=is_anime_list)
			if not meta: return
			meta_get = meta.get
			cm = []
			cm_append = cm.append
			properties = {}
			orig_season, orig_episode = ep_data_get('season'), ep_data_get('episode')
			unwatched = ep_data_get('unwatched', False)
			_position = ep_data_get('custom_order', _position)
			tmdb_id, tvdb_id, imdb_id, title, show_year = meta_get('tmdb_id'), meta_get('tvdb_id'), meta_get('imdb_id'), meta_get('title'), meta_get('year') or '2050'
			season_data = meta_get('season_data')
			watched_info = ws.watched_info_episode(meta_get('tmdb_id'), watched_db)
			# #1 C407: a rewatch cursor for this show offers the literal next episode after it (or,
			# from the context menu, that episode itself), watched or not. Local only, never cached
			# per show; the list cache key carries the cursor state.
			rewatch = None
			if list_type_starts_with('next') and not unwatched:
				try:
					from modules.rewatch_cursor import seed as rewatch_seed
					rewatch = rewatch_seed(tmdb_id)
				except Exception: rewatch = None
			if rewatch:
				r_season, r_episode, show_self = rewatch
				if show_self: orig_season, orig_episode = r_season, r_episode
				else: orig_season, orig_episode = ws.get_next(r_season, r_episode, watched_info, season_data, 0, meta)
				if not orig_season or not orig_episode: return
			elif list_type_starts_with('next'):
				# Per-show result cache (#121): the (season, episode) resolved below is keyed on the
				# seed, the method and every watched row for this show, so a rebuild recomputes
				# only shows whose watched rows changed. Watchlist/favourite "unwatched" entries
				# (episode 0) are trivial and never cached.
				nextep_key = None if unwatched else ws.next_episode_cache_key(watched_info, nextep_content, orig_season, orig_episode)
				resolved = widget_cache.get_next_episode(tmdb_id, nextep_key) if nextep_key else None
				if resolved is widget_cache.NEGATIVE:
					nextep_negative_hits.append(tmdb_id)
					return
				elif resolved:
					orig_season, orig_episode = resolved
					nextep_hits.append(tmdb_id)
				else:
					# get_next_episodes() picked orig_season/orig_episode by raw (season, episode)
					# order -- correct it into the show's own group order first when it has a
					# group-native traversal, or "next" walks on from the wrong episode (#76).
					# Computed once and threaded through both calls below -- each call otherwise
					# refetches every group-native season's episode metadata on its own.
					group_pairs = ws.group_ordered_episode_pairs(meta)
					orig_season, orig_episode = ws.group_corrected_next_seed(meta, watched_info, orig_season, orig_episode, group_pairs=group_pairs)
					last_watched_season, last_watched_episode = orig_season, orig_episode
					orig_season, orig_episode = ws.get_next(orig_season, orig_episode, watched_info, season_data, nextep_content, meta, group_pairs=group_pairs)
					# Weekly anime: stale season/show cache often stops at the last watched ep until expiry.
					if (not orig_season or not orig_episode) and meta_get('status') not in ('Ended', 'Canceled'):
						try:
							from modules.metadata import refresh_airing_show_meta
							refresh_airing_show_meta(meta_get('tmdb_id'), last_watched_season)
							meta = tvshow_meta('tmdb_id', meta_get('tmdb_id'), api_key, mpaa_region_value, current_date, current_time, is_anime_list=is_anime_list)
							if not meta: return
							meta_get = meta.get
							season_data = meta_get('season_data')
							watched_info = ws.watched_info_episode(meta_get('tmdb_id'), watched_db)
							orig_season, orig_episode = ws.get_next(last_watched_season, last_watched_episode, watched_info, season_data, nextep_content, meta)
						except: pass
					if nextep_key:
						widget_cache.set_next_episode(tmdb_id, nextep_key, orig_season, orig_episode, meta_get('status'))
				if not orig_season or not orig_episode: return
				if ws.get_watched_status_episode(watched_info, (orig_season, orig_episode)): return
			episodes_data = episodes_meta(orig_season, meta)
			if not episodes_data: return
			item = next((i for i in episodes_data if i['episode'] == orig_episode), None)
			if not item: return
			item_get = item.get
			season, episode, ep_name = item_get('season'), item_get('episode'), item_get('title')
			if list_type_compare in ('trakt_calendar', 'mdblist_calendar', 'punchplay_calendar', 'simkl_calendar', 'trakt_recently_aired'):
				episode_date, premiered = _calendar_episode_date(ep_data_get('first_aired'), item_get('premiered'), adjust_hours)
			else:
				episode_date, premiered = adjust_premiered_date(item_get('premiered'), adjust_hours)
			episode_type = item_get('episode_type') or ''
			episode_id = item_get('episode_id') or None
			if not episode_date or current_date < episode_date:
				if episode_date and list_type_starts_with('next_'): future_dates.append(episode_date)
				if list_type_starts_with('next_'):
					if not episode_date: return
					if not include_unaired: return
					if not date_difference(current_date, episode_date, 7): return
				unaired = True
			else: unaired = False
			orig_title, rootname, trailer, genre = meta_get('original_title'), meta_get('rootname'), str(meta_get('trailer')), meta_get('genre')
			mpaa, tvshow_plot, studio, show_status = meta_get('mpaa'), meta_get('plot'), meta_get('studio'), meta_get('status')
			cast = meta_get('short_cast', []) or meta_get('cast', []) or []
			if rpdb_api_key:
				try: show_poster = meta_get('rpdb_poster') % rpdb_api_key + rpdb_format
				except: show_poster = meta_get('poster') or poster_empty
			else: show_poster = meta_get('poster') or poster_empty
			show_fanart = meta_get('fanart') or fanart_empty
			show_clearlogo = meta_get('clearlogo') or ''
			show_landscape = meta_get('landscape') or ''
			try: year = premiered.split('-')[0]
			except: year = show_year or '2050'
			try:
				poster_path = next((i['poster_path'] for i in season_data if i['season_number'] == int(season)), None)
				season_poster = 'https://image.tmdb.org/t/p/w780%s' % poster_path if poster_path is not None else show_poster
			except: season_poster = show_poster
			mapped = _group_display_numbers(tmdb_id, season, episode, episode_id, group_cache)
			display_season, display_episode = (mapped['season'], mapped['episode']) if mapped else (season, episode)
			str_episode_zfill2 = str(display_episode).zfill(2)
			if display_format == 0: title_str = '%s - ' % title
			else: title_str = ''
			if display_format in (0, 1): seas_ep = '%sx%s. ' % (str(display_season), str_episode_zfill2)
			else: seas_ep = ''
			if not list_type_starts_with('next_'):
				playcount = ws.get_watched_status_episode(watched_info, (season, episode))
				if playcount and hide_watched and not rewatch: return
			if list_type_starts_with('next_'):
				playcount = 0
				if include_airdate:
					if episode_date: display_premiered = '[%s] ' % make_day(current_date, episode_date)
					else: display_premiered = '[UNKNOWN] '
				else: display_premiered = ''
				if unwatched: highlight_start, highlight_end = '[COLOR darkgoldenrod]', '[/COLOR]'
				elif unaired: highlight_start, highlight_end = '[COLOR red]', '[/COLOR]'
				else: highlight_start, highlight_end = '', ''
				# Title mirrors settings format without BBCode (widgets/skins that bind Title).
				display_title = '%s%s%s%s' % (display_premiered, title_str, seas_ep, ep_name)
				display = '%s%s%s%s%s%s' % (display_premiered, title_str, highlight_start, seas_ep, ep_name, highlight_end)
			elif list_type_compare in ('trakt_calendar', 'mdblist_calendar', 'punchplay_calendar', 'simkl_calendar'):
				if not episode_date:
					display_premiered = 'UNKNOWN'
				else:
					display_premiered = make_day(
						current_date, episode_date, calendar_date_strftime,
						use_words=calendar_use_words, include_date=calendar_include_date)
				display = display_title = '[%s] %s%s%s' % (display_premiered, title_str, seas_ep, ep_name)
			else: display = display_title = '%s%s%s' % (title_str, seas_ep, ep_name)
			progress_aired_eps, total_unwatched = None, None
			if unwatched_info:
				try:
					progress_aired_eps = ws.show_facts(meta, show_facts_map)[0]
					total_unwatched = ws.get_watched_status_tvshow(watched_info_tvshow.get(str(tmdb_id), None), progress_aired_eps)[2]
				except: progress_aired_eps, total_unwatched = None, None
				if unwatched_in_title and total_unwatched:
					suffix = ' (%s)' % total_unwatched
					display, display_title = display + suffix, display_title + suffix
			if no_spoilers and not playcount: thumb, plot = show_landscape or show_fanart, tvshow_plot or '* Hidden to Prevent Spoilers *'
			else: thumb, plot = item_get('thumb', None) or show_landscape or show_fanart, item_get('plot') or tvshow_plot
			duration = item_get('duration')
			if not duration:
				duration = meta_get('duration')
				item['duration'] = duration
			bookmarks = ws.get_bookmarks_episode(tmdb_id, season, watched_db)
			progress = ws.get_progress_status_episode(bookmarks, episode)
			play_params = build_url({'mode': play_mode, 'media_type': 'episode', 'tmdb_id': tmdb_id, 'season': season, 'episode': episode, 'playcount': playcount,
									'episode_id': episode_id, playback_key: playback_key})
			extras_params = build_url({'mode': 'extras_menu_choice', 'tmdb_id': tmdb_id, 'media_type': 'episode', 'is_external': is_external})
			options_params = build_url({'mode': 'options_menu_choice', 'content': list_type, 'tmdb_id': tmdb_id, 'poster': show_poster, 'is_external': is_external,
										'season': season, 'episode': episode, 'episode_id': episode_id})
			playback_options_params = build_url({'mode': 'playback_choice', 'media_type': 'episode', 'meta': tmdb_id, 'season': season, 'playcount': playcount,
											'episode': episode, 'episode_id': episode_id})
			cm_append(['extras', ('[B]Extras[/B]', 'RunPlugin(%s)' % extras_params)])
			cm_append(['options', ('[B]Options[/B]', 'RunPlugin(%s)' % options_params)])
			cm_append(['playback_options', ('[B]Play Options[/B]', 'RunPlugin(%s)' % \
						build_url({'mode': 'playback_choice', 'media_type': 'episode', 'meta': tmdb_id, 'season': season, 'episode': episode, 'episode_id': episode_id}))])
			settings.append_source_shortcut_context_menus(cm_append, build_url, cm_sort_order, 'episode', tmdb_id, season, episode, playcount)
			settings.append_external_scraper_settings_cm(cm_append, build_url)
			cm_append(['browse_seasons', ('[B]Browse Seasons[/B]', window_command % build_url({'mode': 'build_season_list', 'tmdb_id': tmdb_id}))])
			cm_append(['browse_episodes', ('[B]Browse Episodes[/B]', window_command % build_url({'mode': 'build_episode_list', 'tmdb_id': tmdb_id, 'season': season}))])
			# List managers stay show-scoped (watchlist/library/etc). MDBList static add/remove uses season/episode when present.
			trakt_manager_params, simkl_manager_params, punchplay_manager_params, mdblist_manager_params, tmdb_manager_params = '', '', '', '', ''
			if settings.trakt_user_active():
				trakt_manager_params = build_url({'mode': 'trakt_manager_choice', 'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'tvdb_id': tvdb_id, 'media_type': 'tvshow',
												'title': title, 'icon': show_poster, 'season': season, 'episode': episode, 'episode_id': episode_id})
			if settings.simkl_user_active():
				simkl_params = {'mode': 'simkl_manager_choice', 'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'tvdb_id': tvdb_id, 'media_type': 'tvshow',
								'title': title, 'icon': show_poster}
				if is_anime_list is True: simkl_params['simkl_media_kind'] = 'anime'
				simkl_manager_params = build_url(simkl_params)
			if settings.punchplay_user_active():
				punchplay_manager_params = build_url({'mode': 'punchplay_manager_choice', 'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'tvdb_id': tvdb_id, 'media_type': 'tvshow',
													'title': title, 'icon': show_poster})
			if settings.mdblist_user_active():
				mdblist_manager_params = build_url({'mode': 'mdblist_manager_choice', 'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'tvdb_id': tvdb_id, 'media_type': 'tvshow',
													'title': title, 'icon': show_poster, 'season': season, 'episode': episode, 'episode_id': episode_id})
			if settings.tmdblist_user_active():
				tmdb_manager_params = build_url({'mode': 'tmdblists_manager_choice', 'media_type': 'tv', 'tmdb_id': tmdb_id, 'icon': show_poster})
			personal_manager_params = build_url({'mode': 'personallists_manager_choice', 'list_type': 'tvshow', 'tmdb_id': tmdb_id, 'title': title,
												'premiered': meta_get('premiered'), 'icon': show_poster})
			favorites_manager_params = build_url({'mode': 'favorites_manager_choice', 'media_type': 'tvshow', 'tmdb_id': tmdb_id, 'title': title})
			if mdblist_manager_params: cm_append(['mdblist_manager', ('[B]MDBList Manager[/B]', 'RunPlugin(%s)' % mdblist_manager_params)])
			if punchplay_manager_params: cm_append(['punchplay_manager', ('[B]PunchPlay Manager[/B]', 'RunPlugin(%s)' % punchplay_manager_params)])
			if simkl_manager_params: cm_append(['simkl_manager', ('[B]Simkl Lists Manager[/B]', 'RunPlugin(%s)' % simkl_manager_params)])
			if tmdb_manager_params: cm_append(['tmdb_manager', ('[B]TMDb Lists Manager[/B]', 'RunPlugin(%s)' % tmdb_manager_params)])
			if trakt_manager_params: cm_append(['trakt_manager', ('[B]Trakt Lists Manager[/B]', 'RunPlugin(%s)' % trakt_manager_params)])
			settings.append_list_shortcut_context_menus(cm_append, build_url, cm_sort_order, 'tvshow', tmdb_id, imdb_id, tvdb_id, title, show_poster)
			cm_append(['personal_manager', ('[B]Personal Lists Manager[/B]', 'RunPlugin(%s)' % personal_manager_params)])
			cm_append(['favorites_manager', ('[B]Favorites Manager[/B]', 'RunPlugin(%s)' % favorites_manager_params)])
			if not unaired:
				if playcount:
					cm_append(['mark_watched', ('[B]Mark Unwatched[/B]', 'RunPlugin(%s)' % build_url({'mode': 'watched_status.mark_episode', 'action': 'mark_as_unwatched',
												'tmdb_id': tmdb_id, 'tvdb_id': tvdb_id, 'season': season, 'episode': episode,  'title': title}))])
					cm_append(['mark_watched', ('[B]Rewatch From Here[/B]', 'RunPlugin(%s)' % build_url({'mode': 'watched_status.rewatch_cursor', 'action': 'set',
												'tmdb_id': tmdb_id, 'season': season, 'episode': episode}))])
				else: cm_append(['mark_watched', ('[B]Mark Watched[/B]', 'RunPlugin(%s)' % build_url({'mode': 'watched_status.mark_episode', 'action': 'mark_as_watched',
											'tmdb_id': tmdb_id, 'tvdb_id': tvdb_id, 'season': season, 'episode': episode,  'title': title}))])
				if progress:
					cm_append(['mark_watched', ('[B]Clear Progress[/B]', 'RunPlugin(%s)' % \
								build_url({'mode': 'watched_status.erase_bookmark', 'media_type': 'episode', 'tmdb_id': tmdb_id,
											'season': season, 'episode': episode, 'refresh': 'true'}))])
				if unwatched_info and total_unwatched is not None and progress_aired_eps != total_unwatched:
					properties.update({'watchedepisodes': '1', 'unwatchedepisodes': str(total_unwatched)})
			if rewatch:
				cm_append(['mark_watched', ('[B]Stop Rewatching[/B]', 'RunPlugin(%s)' % build_url({'mode': 'watched_status.rewatch_cursor', 'action': 'clear',
								'tmdb_id': tmdb_id, 'season': season, 'episode': episode}))])
			if list_type_starts_with('next_') and (season, episode) != (1, 1):
				cm_append(['unmark_previous_episode', ('[B]Unmark Previous Watched[/B]', 'RunPlugin(%s)' % \
								build_url({'mode': 'watched_status.unmark_previous_episode', 'action': 'mark_as_unwatched', 'tmdb_id': tmdb_id, 'tvdb_id': tvdb_id,
											'season': season, 'episode': episode, 'title': title, 'refresh': 'true'}))])
			if is_external:
				cm.extend([['refresh', ('[B]Refresh Widgets[/B]', 'RunPlugin(%s)' % build_url({'mode': 'refresh_widgets'}))],
						['reload', ('[B]Reload Widgets[/B]', 'RunPlugin(%s)' % build_url({'mode': 'kodi_refresh'}))]])
			if custom_cm_menu:
				try: cm = sorted([i for i in cm if i[0] in cm_sort_order], key=lambda k: cm_sort_order[k[0]])
				except: pass
			cm = [i[1] for i in cm]
			# Legacy metacache used 1-tuples for studio; setStudios requires a list.
			if isinstance(studio, tuple): studio = list(studio)
			elif not studio: studio = []
			full_cast = cast + (item_get('guest_stars') or [])
			# Plain data first, then the ListItem (#155): the Next Episodes list cache stores these rows.
			row = {'label': display, 'cm': cm, 'properties': properties,
				'info': {'original_title': orig_title, 'tvshow_title': title, 'title': display_title, 'genres': genre, 'playcount': playcount,
					'season': display_season, 'episode': display_episode, 'plot': plot, 'first_aired': premiered, 'duration': duration,
					'imdb': imdb_id, 'unique_ids': {'imdb': imdb_id, 'tmdb': str(tmdb_id), 'tvdb': str(tvdb_id)}, 'countries': meta_get('country', []),
					'trailer': trailer, 'tvshow_status': show_status, 'studios': studio, 'writers': item_get('writer'), 'directors': item_get('director'),
					'year': int(year), 'rating': item_get('rating'), 'votes': item_get('votes'), 'mpaa': mpaa},
				'cast': [{'name': item['name'], 'role': item['role'], 'thumbnail': item['thumbnail']} for item in full_cast],
				'art': {'poster': show_poster, 'fanart': show_fanart, 'thumb': thumb, 'icon':thumb, 'clearlogo': show_clearlogo, 'landscape': show_landscape,
						'season.poster': season_poster, 'tvshow.poster': show_poster, 'tvshow.clearlogo': show_clearlogo}}
			if progress and not unaired:
				# Time only — total would make Kodi/skins show a resume dialog we cannot honour.
				row['resume_seconds'] = ws.get_resume_seconds(progress, duration)
				properties['WatchedProgress'] = progress
			properties.update({
				'episode_type': episode_type, 'redlight.extras_params': extras_params, 'redlight.options_params': options_params,
				'redlight.playback_options_params': playback_options_params,
				'redlight.trakt_manager_params': trakt_manager_params,
				'redlight.simkl_manager_params': simkl_manager_params,
				'redlight.punchplay_manager_params': punchplay_manager_params,
				'redlight.mdblist_manager_params': mdblist_manager_params,
				'redlight.personal_manager_params': personal_manager_params,
				'redlight.tmdb_manager_params': tmdb_manager_params,
				'redlight.favorites_manager_params': favorites_manager_params
				})
			listitem = render_episode_row(row, make_listitem, kodi_actor)
			item_list_append({'list_items': (play_params, listitem, False), 'row': row, 'first_aired': premiered, 'name': '%s - %sx%s' % (title, str(display_season), str_episode_zfill2),
							'unaired': unaired, 'last_played': ep_data_get('last_played', resinsert), 'sort_order': _position, 'unwatched': ep_data_get('unwatched'),
							'tmdb_id': tmdb_id})
		except Exception as e:
			# Silent drops blank calendars/next-ep lists; log so meta/InfoTag failures are visible.
			try: kodi_utils.logger('Red Light', 'build_single_episode item failed (%s): %s' % (list_type, e))
			except: pass
	kodi_actor, make_listitem, build_url = kodi_utils.kodi_actor(), kodi_utils.make_listitem, kodi_utils.build_url
	poster_empty, fanart_empty = kodi_utils.get_icon('box_office'), kodi_utils.addon_fanart()
	handle, is_external = int(sys.argv[1]), kodi_utils.external()
	is_anime_list = 'is_anime_list' in params
	# Calendars / Next Up are not anime-filtered shelves — never pass False into meta_valid_check.
	if list_type in ('episode.trakt', 'episode.mdblist', 'episode.mdblist_next', 'episode.punchplay'):
		is_anime_list = None
	elif not is_anime_list and settings.include_anime_tvshow():
		is_anime_list = None
	item_list, airing_today, unwatched, return_results = [], [], [], False
	cache_next_list, future_dates = list_type == 'episode.next', []
	resinsert = ''
	item_list_append = item_list.append
	window_command = 'ActivateWindow(Videos,%s,return)' if is_external else 'Container.Update(%s)'
	no_spoilers = settings.avoid_episode_spoilers()
	watched_indicators = settings.watched_indicators()
	# MDBList Lists → Next Up always uses MDBList watched history (not global Watched Status Provider).
	if list_type == 'episode.mdblist_next': watched_indicators = 3
	if list_type in ('episode.trakt', 'episode.mdblist', 'episode.punchplay'):
		display_format = settings.calendar_display_format(is_external)
		calendar_date_strftime, calendar_use_words, calendar_include_date = settings.calendar_date_label_options()
		calendar_date_format = None if calendar_use_words else calendar_date_strftime
	else:
		display_format = settings.single_ep_display_format(is_external)
		calendar_date_strftime, calendar_use_words, calendar_include_date = '%Y-%m-%d', True, False
		calendar_date_format = None
	current_date, current_time, adjust_hours = get_datetime(), get_current_timestamp(), settings.date_offset()
	unwatched_info = settings.single_ep_unwatched_episodes()
	unwatched_in_title = settings.single_ep_unwatched_in_title()
	hide_watched = is_external and settings.widget_hide_watched() and list_type != 'episode.recently_watched'
	api_key, mpaa_region_value = settings.tmdb_api_key(), settings.mpaa_region()
	group_cache = {}
	cm_sort_order, ignore_articles = settings.cm_sort_order(), settings.ignore_articles()
	custom_cm_menu = cm_sort_order != settings.cm_default_order()
	rpdb_info = settings.rpdb_info('tvshow')
	rpdb_api_key, rpdb_format = rpdb_info['rpdb_api_key'], rpdb_info['rpdb_format']
	playback_key = settings.playback_key()
	play_mode = 'playback.%s' % playback_key
	watched_db = ws.get_database(watched_indicators)
	watched_info_tvshow = ws.watched_info_tvshow(watched_db) if unwatched_info else {}
	build_started, nextep_hits, nextep_negative_hits = time.time(), [], []
	if list_type in ('episode.next', 'episode.mdblist_next'):
		mdblist_menu_next = list_type == 'episode.mdblist_next'
		include_unwatched, include_unaired, nextep_content = settings.nextep_include_unwatched(), settings.nextep_include_unaired(), settings.nextep_method()
		sort_key, sort_direction = settings.nextep_sort_key(), settings.nextep_sort_direction()
		include_airdate = settings.nextep_include_airdate()
		# Keep external watched DBs fresh before building Next (In Progress already refreshes).
		if watched_indicators == 3 and settings.mdblist_user_active():
			try: ws._refresh_mdblist_tvshow_watched()
			except: pass
		elif watched_indicators == 1 and settings.trakt_user_active():
			try: ws._refresh_trakt_tvshow_watched()
			except: pass
		elif watched_indicators == 2 and settings.simkl_user_active():
			try: ws._refresh_simkl_tvshow_watched()
			except: pass
		elif watched_indicators == 4 and settings.punchplay_user_active():
			try: ws._refresh_punchplay_tvshow_watched()
			except: pass
		data = ws.get_next_episodes(nextep_content, watched_indicators)
		if settings.nextep_limit_history(): data = data[:settings.nextep_limit()]
		hidden_list = set(ws.get_hidden_progress_items(watched_indicators) or [])
		if hidden_list:
			data = [i for i in data if int(i['media_ids']['tmdb']) not in hidden_list]
		if watched_indicators in (1, 2, 3, 4):
			resformat, resinsert = '%Y-%m-%dT%H:%M:%S.%fZ', '2000-01-01T00:00:00.000Z'
			list_type = {1: 'episode.next_trakt', 2: 'episode.next_simkl', 3: 'episode.next_mdblist', 4: 'episode.next_punchplay'}[watched_indicators]
		else: resformat, resinsert, list_type = '%Y-%m-%d %H:%M:%S', '2000-01-01 00:00:00', 'episode.next_redlight'
		if mdblist_menu_next: category_override = 'MDBList Next Up'
		if include_unwatched != 0:
			if include_unwatched in (1, 3):
				try:
					watchlist = _nextep_indicator_watchlist(watched_indicators)
					unwatched.extend([{'media_ids': i['media_ids'], 'season': 1, 'episode': 0, 'unwatched': True, 'title': i['title']} for i in watchlist])
				except: pass
			if include_unwatched in (2, 3):
				from caches.favorites_cache import favorites_cache
				try:
					favorites = favorites_cache.get_favorites('tvshow')
					unwatched.extend([{'media_ids': {'tmdb': int(i['tmdb_id'])}, 'season': 1, 'episode': 0, 'unwatched': True, 'title': i['title']} \
									for i in favorites if not int(i['tmdb_id']) in [x['media_ids']['tmdb'] for x in data]])
				except: pass
			data += unwatched
	elif list_type == 'episode.progress': data = ws.get_in_progress_episodes()
	elif list_type == 'episode.recently_watched': data = ws.get_recently_watched('episode', short_list=True)
	elif list_type == 'episode.trakt':
		from apis.trakt_api import trakt_get_my_calendar
		recently_aired = params.get('recently_aired', None)
		data = trakt_get_my_calendar(recently_aired, get_datetime())
		hidden_list = ws.get_hidden_progress_items(watched_indicators)
		if hidden_list: data = [i for i in data if not i['media_ids']['tmdb'] in hidden_list]
		list_type = 'episode.trakt_recently_aired' if recently_aired else 'episode.trakt_calendar'
		if settings.flatten_episodes():
			try:
				duplicates = set()
				data.sort(key=lambda i: i['sort_title'])
				data = [i for i in data if not ((i['media_ids']['tmdb'], i['first_aired'].split('T')[0]) in duplicates
						or duplicates.add((i['media_ids']['tmdb'], i['first_aired'].split('T')[0])))]
			except: pass
		else:
			try: data = sorted(data, key=lambda i: (i['sort_title'], i.get('first_aired', '2100-12-31')), reverse=True)
			except: data = sorted(data, key=lambda i: i['sort_title'], reverse=True)
	elif list_type == 'episode.mdblist':
		from apis.mdblist_api import mdblist_get_my_calendar
		data = mdblist_get_my_calendar()
		hidden_list = ws.get_hidden_progress_items(watched_indicators)
		if hidden_list: data = [i for i in data if not i['media_ids']['tmdb'] in hidden_list]
		list_type = 'episode.mdblist_calendar'
		if settings.flatten_episodes():
			try:
				duplicates = set()
				data.sort(key=lambda i: i['sort_title'])
				data = [i for i in data if not ((i['media_ids']['tmdb'], i['first_aired'].split('T')[0]) in duplicates
						or duplicates.add((i['media_ids']['tmdb'], i['first_aired'].split('T')[0])))]
			except: pass
		else:
			try: data = sorted(data, key=lambda i: (i['sort_title'], i.get('first_aired', '2100-12-31')), reverse=True)
			except: data = sorted(data, key=lambda i: i['sort_title'], reverse=True)
	elif list_type == 'episode.punchplay':
		from apis.punchplay_api import punchplay_get_my_calendar
		data = punchplay_get_my_calendar()
		hidden_list = ws.get_hidden_progress_items(watched_indicators)
		if hidden_list: data = [i for i in data if not i['media_ids']['tmdb'] in hidden_list]
		list_type = 'episode.punchplay_calendar'
		if settings.flatten_episodes():
			try:
				duplicates = set()
				data.sort(key=lambda i: i['sort_title'])
				data = [i for i in data if not ((i['media_ids']['tmdb'], i['first_aired'].split('T')[0]) in duplicates
						or duplicates.add((i['media_ids']['tmdb'], i['first_aired'].split('T')[0])))]
			except: pass
		else:
			try: data = sorted(data, key=lambda i: (i['sort_title'], i.get('first_aired', '2100-12-31')), reverse=True)
			except: data = sorted(data, key=lambda i: i['sort_title'], reverse=True)
	elif list_type == 'episode.simkl':
		from apis.simkl_api import simkl_get_my_calendar
		data = simkl_get_my_calendar()
		hidden_list = ws.get_hidden_progress_items(watched_indicators)
		if hidden_list: data = [i for i in data if not i['media_ids']['tmdb'] in hidden_list]
		list_type = 'episode.simkl_calendar'
		if settings.flatten_episodes():
			try:
				duplicates = set()
				data.sort(key=lambda i: i['sort_title'])
				data = [i for i in data if not ((i['media_ids']['tmdb'], i['first_aired'].split('T')[0]) in duplicates
						or duplicates.add((i['media_ids']['tmdb'], i['first_aired'].split('T')[0])))]
			except: pass
		else:
			try: data = sorted(data, key=lambda i: (i['sort_title'], i.get('first_aired', '2100-12-31')), reverse=True)
			except: data = sorted(data, key=lambda i: i['sort_title'], reverse=True)
	else: data, return_results = sorted(params, key=lambda i: i['custom_order']), True
	# Keyed after the provider refresh and fetches above, so it names the state this list is built from.
	nextep_list_key = nextep_list_cache.cache_key(is_external, 'is_anime_list' in params) if cache_next_list else None
	list_type_compare = list_type.split('episode.')[1]
	list_type_starts_with = list_type_compare.startswith
	# One read for every show's cached facts (unwatched-count suffix), instead of a per-show query.
	show_facts_map = widget_cache.get_show_facts([i['media_ids'].get('tmdb') for i in data if i.get('media_ids')]) if unwatched_info else {}
	threads = TaskPool().tasks_enumerate(_process, data, min(len(data), settings.max_threads()))
	[i.join() for i in threads]
	if return_results: return [(i['list_items'], i['sort_order']) for i in item_list]
	if list_type_starts_with('next_'):
		kodi_utils.logger('Red Light', 'build_single_episode(%s): %s shows, %s listed, next-episode cache %s hit / %s negative / %s miss, %.1fs'
			% (list_type, len(data), len(item_list), len(nextep_hits), len(nextep_negative_hits),
			len(data) - len(nextep_hits) - len(nextep_negative_hits), time.time() - build_started))
		touched = {}
		if sort_key == 'updated':
			# #1 "Recently Updated": the later of the last watched row and the last watched-state change.
			try:
				from modules.show_touch import load as load_touch
				touched = load_touch()
			except Exception: touched = {}
			for i in item_list:
				try:
					dt = jsondate_to_datetime(i['last_played'], resformat)
					# Tracker rows are UTC ('...Z'); Red Light's own watched rows are local time.
					played = calendar.timegm(dt.timetuple()) if resformat.endswith('Z') else dt.timestamp()
				except Exception: played = 0.0
				i['updated'] = max(played, touched.get(str(i.get('tmdb_id')), 0.0))
		def func(function):
			if sort_key == 'name': return title_key(function, ignore_articles)
			elif sort_key == 'last_played': return jsondate_to_datetime(function, resformat)
			else: return function
		if settings.nextep_airing_today():
			airing_today = sorted([i for i in item_list if date_difference(current_date, jsondate_to_datetime(i.get('first_aired', '2100-12-31'), '%Y-%m-%d').date(), 0)],
									key=lambda i: func(i[sort_key]), reverse=sort_direction)
			item_list = [i for i in item_list if not i in airing_today]
		else: airing_today = []
		if sort_key in ('last_played', 'updated'):
			unwatched = sorted([i for i in item_list if i['unwatched']], key=lambda i: title_key(i['name'], ignore_articles))
			item_list = sorted([i for i in item_list if not i['unwatched']], key=lambda i: func(i[sort_key]), reverse=sort_direction) + unwatched
		else: item_list = sorted(item_list, key=lambda i: func(i[sort_key]), reverse=sort_direction)
		item_list = airing_today + item_list
	else:
		item_list.sort(key=lambda i: i['sort_order'])
		if list_type_compare in ('trakt_calendar', 'trakt_recently_aired', 'mdblist_calendar', 'punchplay_calendar', 'simkl_calendar'):
			if list_type_compare in ('trakt_calendar', 'mdblist_calendar', 'punchplay_calendar', 'simkl_calendar'): reverse = settings.calendar_sort_order() == 0
			else: reverse = True
			try: item_list = sorted(item_list, key=lambda i: i.get('first_aired', '2100-12-31'), reverse=reverse)
			except:
				item_list = [i for i in item_list if i.get('first_aired') not in (None, 'None', '')]
				item_list = sorted(item_list, key=lambda i: i.get('first_aired'), reverse=reverse)
			if list_type_compare in ('trakt_calendar', 'mdblist_calendar', 'punchplay_calendar', 'simkl_calendar') and not calendar_date_format:
				airing_today = sorted([i for i in item_list if date_difference(current_date, jsondate_to_datetime(i.get('first_aired', '2100-12-31'), '%Y-%m-%d').date(), 0)],
										key=lambda i: i['first_aired'])
				item_list = [i for i in item_list if not i in airing_today]
				item_list = airing_today + item_list
	if cache_next_list:
		try:
			from modules.nextep_warm import request_widget_warm
			request_widget_warm([i['list_items'][0] for i in item_list])
		except Exception: pass
		nextep_list_cache.store(nextep_list_key, is_external, 'is_anime_list' in params, [(i['list_items'][0], i['row']) for i in item_list], future_dates,
			_get_category_name())
	kodi_utils.add_items(handle, [i['list_items'] for i in item_list])
	kodi_utils.set_content(handle, 'episodes')
	kodi_utils.set_category(handle, _get_category_name())
	# Keep plugin order for calendars — Kodi "Sort by Date" was reordering vs day labels.
	if list_type_compare in ('trakt_calendar', 'mdblist_calendar', 'punchplay_calendar', 'simkl_calendar', 'trakt_recently_aired'):
		kodi_utils.set_sort_method(handle, 'none', labelMask='%L')
	kodi_utils.end_directory(handle, cacheToDisc=False)
	kodi_utils.set_view_mode('view.episodes_single', 'episodes', is_external, fallback_view_types=('view.episodes',))
